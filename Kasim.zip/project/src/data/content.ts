export interface Branch {
  id: string;
  name: string;
  address: string;
  hours: string;
  image: string;
}

export const branches: Branch[] = [
  {
    id: 'zhabaeva-106',
    name: 'Жабаева, 106',
    address: 'ул. Жабаева, 106, Петропавловск',
    hours: '10:00 – 20:00',
    image:
      'https://images.pexels.com/photos/7195806/pexels-photo-7195806.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    id: 'zhabaeva-161',
    name: 'Жабаева, 161',
    address: 'ул. Жабаева, 161, Петропавловск',
    hours: '10:00 – 20:00',
    image:
      'https://images.pexels.com/photos/5970246/pexels-photo-5970246.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
  {
    id: 'shazhimbaeva-101',
    name: 'Шажимбаева, 101',
    address: 'ул. Шажимбаева, 101, Петропавловск',
    hours: '10:00 – 20:00',
    image:
      'https://images.pexels.com/photos/7195805/pexels-photo-7195805.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  },
];

export interface Review {
  name: string;
  reviewCount: number;
  date: string;
  text: string;
}

export const reviews: Review[] = [
  {
    name: 'Григорий Журавлёв',
    reviewCount: 1,
    date: '17 августа 2026',
    text: 'Молодой барбер Темирхан качественно подстриг, полностью оправдал и даже больше, с каждым приходом всё лучше и лучше.',
  },
  {
    name: 'Виталий Шевелёв',
    reviewCount: 13,
    date: '19 августа',
    text: 'Отличный барбершоп! Отдельное спасибо мастеру Алексею — настоящий профессионал своего дела. Внимательно выслушал пожелания, всё сделал аккуратно и качественно. Приятная атмосфера, хороший сервис и внимательное отношение к клиенту. Однозначно рекомендую!',
  },
  {
    name: 'Юлия Щербакова',
    reviewCount: 5,
    date: '15 августа 2026',
    text: 'Спасибо большое барберу Александру за качественную работу! Свою работу делает качественно и круто. Желаю больших клиентов и удачи, спасибо за эмоции!',
  },
  {
    name: 'Alisher',
    reviewCount: 1,
    date: '15 августа 2026',
    text: 'Сегодня был тут впервые, спасибо девушке на ресепшене — очень милая, доброжелательная, хороший сервис и стрижка тоже. С радостью приняли, обязательно вернусь.',
  },
  {
    name: 'Seerdeath',
    reviewCount: 6,
    date: '4 августа 2026',
    text: 'Если можно было поставить оценку 10 — поставил бы 10. Барбер Темирхан мастер своего дела, общительный, вежливый. Всем советую — отсюда вы не уйдёте расстроенным своей причёской.',
  },
];

export const brand = {
  instagram: 'kasym_barbershop',
  instagramUrl: 'https://instagram.com/kasym_barbershop',
  city: 'Петропавловск',
  followers: 9296,
  posts: 262,
  hours: '10:00 – 20:00',
};
