import Header from '@/components/Header';
import Hero from '@/components/Hero';
import Academy from '@/components/Academy';
import Branches from '@/components/Branches';
import Reviews from '@/components/Reviews';
import CTASection from '@/components/CTASection';
import Footer from '@/components/Footer';

function App() {
  return (
    <div className="bg-ink-950">
      <Header />
      <main>
        <Hero />
        <Academy />
        <Branches />
        <Reviews />
        <CTASection />
      </main>
      <Footer />
    </div>
  );
}

export default App;
