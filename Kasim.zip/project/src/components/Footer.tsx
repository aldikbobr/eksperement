import { Clock, Instagram, MapPin, Scissors } from 'lucide-react';
import { branches, brand } from '@/data/content';

function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer id="contacts" className="border-t border-white/10 bg-ink-950 py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-12 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <a href="#top" className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-gold-500 text-ink-950">
                <Scissors size={18} strokeWidth={2.25} />
              </span>
              <span className="font-display text-base font-semibold tracking-wide text-white">
                KASYM BARBERSHOP
              </span>
            </a>
            <p className="mt-4 text-sm leading-relaxed text-ink-400">
              Барбершоп и международная академия барберинга в {brand.city}.
            </p>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wide text-white">
              Филиалы
            </h3>
            <ul className="mt-4 space-y-3">
              {branches.map((branch) => (
                <li key={branch.id} className="flex items-start gap-2 text-sm text-ink-400">
                  <MapPin size={15} className="mt-0.5 flex-shrink-0 text-gold-400" />
                  {branch.address}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wide text-white">
              Часы работы
            </h3>
            <div className="mt-4 flex items-center gap-2 text-sm text-ink-400">
              <Clock size={15} className="text-gold-400" />
              Ежедневно, {brand.hours}
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wide text-white">
              Мы в сети
            </h3>
            <a
              href={brand.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-4 inline-flex items-center gap-2 text-sm text-ink-400 transition-colors hover:text-gold-400"
            >
              <Instagram size={15} className="text-gold-400" />
              @{brand.instagram}
            </a>
            <p className="mt-2 text-sm text-ink-500">
              {brand.followers.toLocaleString('ru-RU')} подписчиков
            </p>
          </div>
        </div>

        <div className="mt-14 border-t border-white/10 pt-6 text-center text-xs text-ink-500">
          © {year} Kasym Barbershop. Все права защищены.
        </div>
      </div>
    </footer>
  );
}

export default Footer;
