import { Award, GraduationCap, Trophy, Users } from 'lucide-react';
import { brand } from '@/data/content';

const FEATURES = [
  {
    icon: Trophy,
    title: 'Барберы-чемпионы',
    description:
      'В команде работают профессиональные барберы — победители чемпионатов по барберингу.',
  },
  {
    icon: GraduationCap,
    title: 'Курс «Барбер с нуля»',
    description:
      'Обучаем профессии в собственной академии: от первых ножниц до уверенной работы с клиентами.',
  },
  {
    icon: Award,
    title: 'Международный уровень',
    description:
      'Стандарты сервиса и техники, признанные на международных площадках барберинга.',
  },
  {
    icon: Users,
    title: `${brand.followers.toLocaleString('ru-RU')}+ подписчиков`,
    description:
      'Сообщество, которое растёт благодаря качеству стрижек и честным отзывам клиентов.',
  },
];

function Academy() {
  return (
    <section id="academy" className="relative bg-ink-950 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 items-center gap-14 lg:grid-cols-2">
          <div className="relative">
            <div className="overflow-hidden rounded-2xl">
              <img
                src="https://images.pexels.com/photos/2062463/pexels-photo-2062463.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                alt="Барбер выполняет традиционное бритьё опасной бритвой"
                className="h-[520px] w-full object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -right-6 hidden rounded-2xl bg-gold-500 p-6 shadow-xl sm:block">
              <div className="font-display text-4xl font-semibold text-ink-950">
                №1
              </div>
              <div className="text-xs font-medium uppercase tracking-wide text-ink-900">
                в Петропавловске
              </div>
            </div>
          </div>

          <div>
            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-gold-400">
              Наша академия
            </span>
            <h2 className="mt-3 font-display text-4xl font-semibold uppercase leading-tight text-white sm:text-5xl">
              Международная академия барберинга
            </h2>
            <p className="mt-5 text-base leading-relaxed text-ink-300">
              Kasym Barbershop — это не просто три филиала в Петропавловске, а
              полноценная школа мастерства. Мы растим чемпионов и передаём
              опыт новому поколению барберов через курс «Барбер с нуля».
            </p>

            <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-2">
              {FEATURES.map((feature) => {
                const Icon = feature.icon;
                return (
                  <div
                    key={feature.title}
                    className="group rounded-xl border border-white/10 bg-white/[0.03] p-5 transition-colors hover:border-gold-500/40 hover:bg-white/[0.06]"
                  >
                    <span className="inline-flex h-11 w-11 items-center justify-center rounded-lg bg-gold-500/15 text-gold-400 transition-colors group-hover:bg-gold-500 group-hover:text-ink-950">
                      <Icon size={20} />
                    </span>
                    <h3 className="mt-4 font-display text-base font-medium uppercase tracking-wide text-white">
                      {feature.title}
                    </h3>
                    <p className="mt-1.5 text-sm leading-relaxed text-ink-400">
                      {feature.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Academy;
