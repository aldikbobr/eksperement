import { useEffect, useState } from 'react';
import { Instagram, Menu, Scissors, X } from 'lucide-react';
import { brand } from '@/data/content';

const NAV_LINKS = [
  { label: 'Филиалы', href: '#branches' },
  { label: 'Академия', href: '#academy' },
  { label: 'Отзывы', href: '#reviews' },
  { label: 'Контакты', href: '#contacts' },
];

function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setIsScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-ink-950/95 backdrop-blur-sm shadow-lg shadow-black/30'
          : 'bg-gradient-to-b from-black/60 to-transparent'
      }`}
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-20 items-center justify-between">
          <a href="#top" className="flex items-center gap-2.5 group">
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-gold-500 text-ink-950 transition-transform duration-300 group-hover:rotate-45">
              <Scissors size={20} strokeWidth={2.25} />
            </span>
            <span className="flex flex-col leading-none">
              <span className="font-display text-lg font-semibold tracking-wide text-white">
                KASYM BARBERSHOP
              </span>
              <span className="text-[11px] uppercase tracking-[0.2em] text-gold-400">
                №1 в Петропавловске
              </span>
            </span>
          </a>

          <nav className="hidden items-center gap-8 lg:flex">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-sm font-medium text-ink-200 transition-colors hover:text-gold-400"
              >
                {link.label}
              </a>
            ))}
          </nav>

          <div className="hidden items-center gap-3 lg:flex">
            <a
              href={brand.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-flex items-center gap-2 rounded-full bg-gold-500 px-5 py-2.5 text-sm font-semibold text-ink-950 transition-all hover:bg-gold-400 hover:shadow-lg hover:shadow-gold-500/25"
            >
              <Instagram size={16} />
              Записаться
            </a>
          </div>

          <button
            className="inline-flex items-center justify-center rounded-full p-2 text-white lg:hidden"
            onClick={() => setIsMenuOpen((v) => !v)}
            aria-label="Открыть меню"
          >
            {isMenuOpen ? <X size={26} /> : <Menu size={26} />}
          </button>
        </div>
      </div>

      {isMenuOpen && (
        <div className="border-t border-white/10 bg-ink-950/98 backdrop-blur-sm lg:hidden">
          <nav className="flex flex-col gap-1 px-4 py-4">
            {NAV_LINKS.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setIsMenuOpen(false)}
                className="rounded-lg px-3 py-3 text-base font-medium text-ink-100 transition-colors hover:bg-white/5 hover:text-gold-400"
              >
                {link.label}
              </a>
            ))}
            <a
              href={brand.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-gold-500 px-5 py-3 text-base font-semibold text-ink-950"
            >
              <Instagram size={18} />
              Записаться
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}

export default Header;
