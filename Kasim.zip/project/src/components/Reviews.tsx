import { Quote, Star } from 'lucide-react';
import { branches, Review, reviews } from '@/data/content';

function rotate(list: Review[], offset: number): Review[] {
  const n = list.length;
  return Array.from({ length: n }, (_, i) => list[(i + offset) % n]);
}

function initials(name: string): string {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0])
    .join('')
    .toUpperCase();
}

const COLUMNS = [
  { offset: 0, duration: '38s' },
  { offset: 2, duration: '30s' },
  { offset: 4, duration: '44s' },
];

function ReviewCard({ review }: { review: Review }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full bg-gold-500/15 font-display text-sm font-semibold text-gold-400">
            {initials(review.name)}
          </span>
          <div>
            <div className="text-sm font-semibold text-white">{review.name}</div>
            <div className="text-xs text-ink-400">
              {review.reviewCount} {review.reviewCount === 1 ? 'отзыв' : 'отзыва'} · {review.date}
            </div>
          </div>
        </div>
        <Quote size={16} className="flex-shrink-0 text-gold-500/40" />
      </div>

      <div className="mt-3 flex gap-0.5">
        {Array.from({ length: 5 }, (_, i) => (
          <Star key={i} size={13} className="fill-gold-400 text-gold-400" />
        ))}
      </div>

      <p className="mt-3 text-sm leading-relaxed text-ink-300">{review.text}</p>
    </div>
  );
}

function ReviewColumn({ offset, duration }: { offset: number; duration: string }) {
  const ordered = rotate(reviews, offset);
  const looped = [...ordered, ...ordered];

  return (
    <div className="pause-on-hover relative h-[640px] overflow-hidden">
      <div className="pointer-events-none absolute inset-x-0 top-0 z-10 h-16 bg-gradient-to-b from-ink-950 to-transparent" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 h-16 bg-gradient-to-t from-ink-950 to-transparent" />
      <div
        className="animate-scroll-up flex flex-col gap-4"
        style={{ animationDuration: duration }}
      >
        {looped.map((review, i) => (
          <ReviewCard key={`${review.name}-${i}`} review={review} />
        ))}
      </div>
    </div>
  );
}

function Reviews() {
  const mainBranch = branches.find((b) => b.id === 'zhabaeva-161');

  return (
    <section id="reviews" className="relative bg-ink-950 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-semibold uppercase tracking-[0.2em] text-gold-400">
            Отзывы клиентов
          </span>
          <h2 className="mt-3 font-display text-4xl font-semibold uppercase leading-tight text-white sm:text-5xl">
            Нам доверяют
          </h2>
          <p className="mt-4 text-base leading-relaxed text-ink-300">
            Реальные отзывы из нашего Instagram — филиал{' '}
            <span className="font-medium text-gold-400">{mainBranch?.name}</span>.
          </p>
        </div>

        <div className="mt-14 grid grid-cols-1 gap-6 md:grid-cols-3">
          {COLUMNS.map((col) => (
            <ReviewColumn key={col.offset} offset={col.offset} duration={col.duration} />
          ))}
        </div>
      </div>
    </section>
  );
}

export default Reviews;
