import { ArrowRight, Instagram, MapPin, Users } from 'lucide-react';
import { brand } from '@/data/content';

function Hero() {
  return (
    <section
      id="top"
      className="relative flex min-h-screen items-center overflow-hidden bg-ink-950"
    >
      <div className="absolute inset-0">
        <img
          src="https://images.pexels.com/photos/897263/pexels-photo-897263.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
          alt="Барбер стрижёт клиента в Kasym Barbershop"
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink-950 via-ink-950/85 to-ink-950/40" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-transparent to-ink-950/60" />
      </div>

      <div className="relative mx-auto w-full max-w-7xl px-4 pt-24 sm:px-6 lg:px-8">
        <div className="max-w-2xl">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-gold-500/30 bg-gold-500/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.15em] text-gold-400">
            Международная академия барберов
          </div>

          <h1 className="font-display text-5xl font-semibold uppercase leading-[1.05] tracking-wide text-white sm:text-6xl lg:text-7xl">
            Барбершоп{' '}
            <span className="text-gold-500">№1</span>
            <br />в Петропавловске
          </h1>

          <p className="mt-6 max-w-xl text-lg leading-relaxed text-ink-200">
            Три филиала, команда барберов-чемпионов и собственная академия
            «Барбер с нуля». Приходите за стрижкой — уходите с уверенностью.
          </p>

          <div className="mt-9 flex flex-wrap items-center gap-4">
            <a
              href={brand.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-full bg-gold-500 px-7 py-3.5 text-sm font-semibold text-ink-950 shadow-lg shadow-gold-500/20 transition-all hover:bg-gold-400 hover:shadow-gold-500/35"
            >
              <Instagram size={18} />
              Записаться в Instagram
            </a>
            <a
              href="#branches"
              className="inline-flex items-center gap-2 rounded-full border border-white/25 px-7 py-3.5 text-sm font-semibold text-white transition-all hover:border-gold-400 hover:text-gold-400"
            >
              Наши филиалы
              <ArrowRight size={16} />
            </a>
          </div>

          <div className="mt-14 grid max-w-lg grid-cols-3 gap-6 border-t border-white/10 pt-8">
            <div>
              <div className="font-display text-3xl font-semibold text-white">
                {brand.followers.toLocaleString('ru-RU')}
              </div>
              <div className="mt-1 flex items-center gap-1.5 text-xs text-ink-300">
                <Users size={13} />
                подписчиков
              </div>
            </div>
            <div>
              <div className="font-display text-3xl font-semibold text-white">3</div>
              <div className="mt-1 flex items-center gap-1.5 text-xs text-ink-300">
                <MapPin size={13} />
                филиала
              </div>
            </div>
            <div>
              <div className="font-display text-3xl font-semibold text-white">
                {brand.posts}
              </div>
              <div className="mt-1 flex items-center gap-1.5 text-xs text-ink-300">
                <Instagram size={13} />
                публикации
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default Hero;
