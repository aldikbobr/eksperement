import { Instagram } from 'lucide-react';
import { brand } from '@/data/content';

function CTASection() {
  return (
    <section className="relative overflow-hidden bg-ink-900 py-20">
      <div className="absolute inset-0">
        <img
          src="https://images.pexels.com/photos/13138585/pexels-photo-13138585.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
          alt="Барбер завершает стрижку клиента"
          className="h-full w-full object-cover opacity-25"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink-950 via-ink-950/90 to-ink-950/70" />
      </div>

      <div className="relative mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
        <h2 className="font-display text-3xl font-semibold uppercase leading-tight text-white sm:text-4xl">
          Готовы к новому образу?
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-base leading-relaxed text-ink-300">
          Запишитесь в один из трёх филиалов Kasym Barbershop через Instagram
          — ответим быстро и подберём удобное время.
        </p>
        <a
          href={brand.instagramUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-8 inline-flex items-center gap-2 rounded-full bg-gold-500 px-8 py-3.5 text-sm font-semibold text-ink-950 shadow-lg shadow-gold-500/20 transition-all hover:bg-gold-400 hover:shadow-gold-500/35"
        >
          <Instagram size={18} />
          @{brand.instagram}
        </a>
      </div>
    </section>
  );
}

export default CTASection;
