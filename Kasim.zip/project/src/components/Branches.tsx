import { Clock, MapPin, Navigation } from 'lucide-react';
import { branches } from '@/data/content';

function Branches() {
  return (
    <section id="branches" className="relative bg-ink-900 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-semibold uppercase tracking-[0.2em] text-gold-400">
            Где нас найти
          </span>
          <h2 className="mt-3 font-display text-4xl font-semibold uppercase leading-tight text-white sm:text-5xl">
            Три филиала в Петропавловске
          </h2>
          <p className="mt-4 text-base leading-relaxed text-ink-300">
            Выбирайте филиал, который ближе — сервис и качество стрижки везде
            одинаково высокие.
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-8 lg:grid-cols-3">
          {branches.map((branch, index) => (
            <div
              key={branch.id}
              className="group overflow-hidden rounded-2xl border border-white/10 bg-ink-950 transition-all duration-300 hover:-translate-y-1.5 hover:border-gold-500/40 hover:shadow-2xl hover:shadow-black/40"
            >
              <div className="relative h-56 overflow-hidden">
                <img
                  src={branch.image}
                  alt={`Филиал Kasym Barbershop на ${branch.name}`}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/20 to-transparent" />
                <span className="absolute left-4 top-4 inline-flex h-9 w-9 items-center justify-center rounded-full bg-gold-500 font-display text-sm font-semibold text-ink-950">
                  {index + 1}
                </span>
              </div>

              <div className="p-6">
                <h3 className="font-display text-2xl font-semibold uppercase tracking-wide text-white">
                  {branch.name}
                </h3>

                <div className="mt-4 flex items-start gap-2.5 text-sm text-ink-300">
                  <MapPin size={16} className="mt-0.5 flex-shrink-0 text-gold-400" />
                  <span>{branch.address}</span>
                </div>
                <div className="mt-2.5 flex items-center gap-2.5 text-sm text-ink-300">
                  <Clock size={16} className="flex-shrink-0 text-gold-400" />
                  <span>{branch.hours}</span>
                </div>

                <a
                  href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                    branch.address
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full border border-white/15 py-2.5 text-sm font-semibold text-white transition-colors hover:border-gold-400 hover:text-gold-400"
                >
                  <Navigation size={15} />
                  Построить маршрут
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Branches;
