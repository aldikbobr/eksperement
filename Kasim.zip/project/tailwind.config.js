/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['Oswald', 'sans-serif'],
        sans: ['Inter', 'sans-serif'],
      },
      colors: {
        gold: {
          50: '#fbf6ea',
          100: '#f4e8c8',
          200: '#e9d093',
          300: '#dcb35f',
          400: '#d09f3e',
          500: '#c08a2e',
          600: '#a06f24',
          700: '#805720',
          800: '#69461f',
          900: '#583b1e',
        },
        ink: {
          50: '#f5f5f4',
          100: '#e5e3e0',
          200: '#cac6c1',
          300: '#a3a09b',
          400: '#7b7873',
          500: '#5c5955',
          600: '#454340',
          700: '#33312f',
          800: '#201f1e',
          900: '#141312',
          950: '#0a0908',
        },
      },
      animation: {
        'scroll-up': 'scroll-up linear infinite',
      },
      keyframes: {
        'scroll-up': {
          '0%': { transform: 'translateY(0)' },
          '100%': { transform: 'translateY(-50%)' },
        },
      },
    },
  },
  plugins: [],
};
