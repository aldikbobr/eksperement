/*
# Create bookings table for Блинный домик cafe

1. New Tables
- `bookings`
  - `id` (uuid, primary key)
  - `name` (text, customer name)
  - `phone` (text, customer phone)
  - `guests` (integer, number of guests)
  - `booking_date` (date, reservation date)
  - `booking_time` (text, reservation time)
  - `comment` (text, optional note from customer)
  - `status` (text, default 'new' — new / confirmed / cancelled)
  - `created_at` (timestamptz)
2. Security
- Enable RLS on `bookings`.
- Single-tenant no-auth app: anon + authenticated can insert and read bookings.
- Anyone can submit a booking (insert). Reads are public so the site could later display them if needed.
*/

CREATE TABLE IF NOT EXISTS bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  phone text NOT NULL,
  guests integer NOT NULL DEFAULT 2,
  booking_date date NOT NULL,
  booking_time text NOT NULL,
  comment text,
  status text NOT NULL DEFAULT 'new',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_insert_bookings" ON bookings;
CREATE POLICY "anon_insert_bookings" ON bookings FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_select_bookings" ON bookings;
CREATE POLICY "anon_select_bookings" ON bookings FOR SELECT
TO anon, authenticated USING (true);
