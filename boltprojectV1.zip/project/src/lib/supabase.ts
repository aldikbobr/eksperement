import { createClient, type SupabaseClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase: SupabaseClient =
  supabaseUrl && supabaseAnonKey
    ? createClient(supabaseUrl, supabaseAnonKey)
    : (undefined as unknown as SupabaseClient);

export interface Booking {
  id: string;
  name: string;
  phone: string;
  guests: number;
  booking_date: string;
  booking_time: string;
  comment?: string | null;
  status: string;
  created_at: string;
}
