import { type ReactNode, type ElementType } from 'react';
import { useReveal } from '@/hooks/useReveal';

interface RevealProps {
  children: ReactNode;
  variant?: 'fade-up' | 'fade-down' | 'fade' | 'scale' | 'left' | 'right';
  delay?: number;
  as?: ElementType;
  className?: string;
}

export default function Reveal({
  children,
  variant = 'fade-up',
  delay = 0,
  as: Tag = 'div',
  className = '',
}: RevealProps) {
  const { ref, visible } = useReveal<HTMLElement>();

  return (
    <Tag
      ref={ref as any}
      className={`reveal reveal-${variant} ${visible ? 'active' : ''} ${className}`}
      style={{ animationDelay: `${delay}ms` }}
    >
      {children}
    </Tag>
  );
}
