import { useState, useEffect, useCallback } from 'react';
import { Star, Heart, Share2, ChevronLeft, ChevronRight } from 'lucide-react';

interface Review {
  name: string;
  badge: string;
  stars: number;
  time: string;
  text: string;
}

interface ReviewsCarouselProps {
  reviews: Review[];
  intervalMs?: number;
}

function StarRating({ rating, size = 16 }: { rating: number; size?: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          size={size}
          className={i <= Math.round(rating) ? 'fill-current' : ''}
          style={{ color: i <= Math.round(rating) ? 'var(--color-golden)' : '#d1d5db' }}
        />
      ))}
    </div>
  );
}

export default function ReviewsCarousel({ reviews, intervalMs = 6000 }: ReviewsCarouselProps) {
  const [current, setCurrent] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  const next = useCallback(() => {
    setCurrent((prev) => (prev + 1) % reviews.length);
  }, [reviews.length]);

  const prev = useCallback(() => {
    setCurrent((prev) => (prev - 1 + reviews.length) % reviews.length);
  }, [reviews.length]);

  const goTo = (index: number) => setCurrent(index);

  useEffect(() => {
    if (isPaused || reviews.length <= 1) return;
    const timer = setInterval(next, intervalMs);
    return () => clearInterval(timer);
  }, [isPaused, next, intervalMs, reviews.length]);

  return (
    <div
      className="relative max-w-2xl mx-auto"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* Carousel viewport */}
      <div className="overflow-hidden rounded-2xl">
        <div
          className="flex transition-transform duration-700 ease-in-out"
          style={{ transform: `translateX(-${current * 100}%)` }}
        >
          {reviews.map((review, i) => (
            <div key={i} className="w-full shrink-0 px-1">
              <div className="card-hover bg-white rounded-2xl p-6 md:p-8 border border-gray-100">
                <div className="flex items-start gap-4 mb-4">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg shrink-0"
                    style={{ background: 'linear-gradient(135deg, #c87f2a, #e0a83b)' }}
                  >
                    {review.name.charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold truncate" style={{ color: 'var(--color-dark)' }}>
                      {review.name}
                    </h4>
                    <p className="text-xs" style={{ color: 'var(--color-mocha)' }}>{review.badge}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 mb-3">
                  <StarRating rating={review.stars} size={16} />
                  <span className="text-xs text-gray-400">{review.time}</span>
                </div>
                <p className="text-sm leading-relaxed" style={{ color: 'var(--color-dark)' }}>
                  {review.text}
                </p>
                <div className="flex items-center gap-4 mt-4 pt-4 border-t border-gray-100">
                  <button className="btn-hover flex items-center gap-1.5 text-sm" style={{ color: 'var(--color-mocha)' }}>
                    <Heart size={15} /> Полезно
                  </button>
                  <button className="btn-hover flex items-center gap-1.5 text-sm" style={{ color: 'var(--color-mocha)' }}>
                    <Share2 size={15} /> Поделиться
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Navigation arrows */}
      {reviews.length > 1 && (
        <>
          <button
            onClick={prev}
            className="absolute top-1/2 -translate-y-1/2 -left-3 md:-left-5 w-10 h-10 rounded-full bg-white border border-gray-200 shadow-md flex items-center justify-center btn-hover"
            style={{ color: 'var(--color-amber)' }}
            aria-label="Предыдущий отзыв"
          >
            <ChevronLeft size={20} />
          </button>
          <button
            onClick={next}
            className="absolute top-1/2 -translate-y-1/2 -right-3 md:-right-5 w-10 h-10 rounded-full bg-white border border-gray-200 shadow-md flex items-center justify-center btn-hover"
            style={{ color: 'var(--color-amber)' }}
            aria-label="Следующий отзыв"
          >
            <ChevronRight size={20} />
          </button>
        </>
      )}

      {/* Dots */}
      {reviews.length > 1 && (
        <div className="flex items-center justify-center gap-2 mt-5">
          {reviews.map((_, i) => (
            <button
              key={i}
              onClick={() => goTo(i)}
              className="transition-all duration-300 rounded-full"
              style={{
                width: i === current ? '24px' : '8px',
                height: '8px',
                background: i === current ? 'var(--color-amber)' : '#d1d5db',
              }}
              aria-label={`Отзыв ${i + 1}`}
            />
          ))}
        </div>
      )}
    </div>
  );
}
