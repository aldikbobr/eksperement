import { useState, useEffect } from 'react';
import {
  MapPin, Clock, Phone, Star, Navigation, Bookmark, Share2,
  UtensilsCrossed, ShoppingBag, Calendar, X, Menu as MenuIcon,
  ChevronDown, Heart, Award, Users,
} from 'lucide-react';
import Reveal from '@/components/Reveal';
import BookingModal from '@/components/BookingModal';
import ReviewsCarousel from '@/components/ReviewsCarousel';

const HERO_IMAGE = 'https://images.pexels.com/photos/5317627/pexels-photo-5317627.jpeg?auto=compress&cs=tinysrgb&w=1920';

const MENU_ITEMS = [
  { name: 'Блины классические', desc: 'Тонкие золотистые блинчики на молоке', price: '350 ₸', tags: ['Еда в заведении', 'Еда навынос'] },
  { name: 'Блины с мясом', desc: 'Сочная начинка из говядины с луком', price: '500 ₸', tags: ['Еда в заведении', 'Еда навынос'] },
  { name: 'Блины с творогом', desc: 'Нежный творог с изюмом и ванилью', price: '420 ₸', tags: ['Еда в заведении', 'Еда навынос'] },
  { name: 'Блины с грибами', desc: 'Жареные шампиньоны со сметаной', price: '480 ₸', tags: ['Еда в заведении'] },
  { name: 'Сырники домашние', desc: 'Пышные сырники со сметаной и вареньем', price: '450 ₸', tags: ['Еда в заведении', 'Еда навынос'] },
  { name: 'Торты на заказ', desc: 'Оригинальное украшение на любой праздник', price: 'от 2500 ₸', tags: ['На заказ'] },
  { name: 'Блины с яблоком', desc: 'Карамелизированные яблоки с корицей', price: '400 ₸', tags: ['Еда в заведении', 'Еда навынос'] },
  { name: 'Блины с клубникой', desc: 'Свежая клубника со взбитыми сливками', price: '520 ₸', tags: ['Еда в заведении'] },
];

const REVIEWS = [
  {
    name: 'Диана Сергазина',
    badge: '1 отзыв',
    stars: 5,
    time: '14 июня 2026',
    text: 'Недавно открыла для себя чайную карту в «Блинном домике», и это оказалось маленьким чудом среди обычных дней. Не пакетированный, не тот, который можно купить и унести домой. Его можно попробовать только здесь, и, кажется, в этом часть его очарования. В какой-то момент ловишь себя на мысли, что перестала думать о работе, проблемах, планах и бесконечном списке дел. Просто сидишь и наслаждаешься моментом. Время словно замедляется.',
  },
  {
    name: 'Анна',
    badge: '3 отзыва · Частый гость · Отзыв подтверждён',
    stars: 5,
    time: '30 июля 2026',
    text: 'Кафе «Блинный Домик» оставило только приятные впечатления. Уютная атмосфера, вежливый и внимательный персонал. Блюда вкусные, свежие и приготовлены с душой. Особенно понравились блины — большой выбор начинок и отличное качество.',
  },
  {
    name: 'Дарига Мустафина',
    badge: '13 отзывов',
    stars: 5,
    time: '21 марта 2026',
    text: 'Теть Лена как всегда держит уровень заведения! Лучший повар — большие порции, свежие ингредиенты, сочетания вкусов вне обсуждения… Рекомендую уху из красной рыбы, роллы с кр рыбкой и чай из облепихи!',
  },
  {
    name: 'Виталий Бугаев',
    badge: '4 отзыва · 8 посещений',
    stars: 5,
    time: '21 ноября 2023',
    text: 'Очень вкусные блюда из обновленного меню, особенно уха по-фински и блинчики с вишней и маскарпоне, да и долма получше чем во многих ресторанах. Всем довольны! Очень приятное место!',
  },
  {
    name: 'Наталья Сорокина',
    badge: '86 отзывов · 1 посещение',
    stars: 5,
    time: '21 мая 2025, изменён',
    text: 'Очень понравилось кафе! Вкусные и сытные блины, большой выбор блюд, дружелюбные сотрудники. Можно упаковать с собой. Хорошее место, чтобы перекусить. Люблю такой уютный, домашний формат заведений: как будто вернулась в детство.',
  },
  {
    name: 'Evgen Pieter',
    badge: '1 отзыв',
    stars: 5,
    time: '19 ноября 2025',
    text: 'Быстрое обслуживание и очень вкусная домашняя кухня, стали часто приезжать сюда обедать, лучшее место на районе.',
  },
  {
    name: 'Boo Min',
    badge: '16 отзывов',
    stars: 5,
    time: '5 мая 2025',
    text: 'Неожиданно приятное место. Вкусно, быстро, вежливые и компетентные сотрудники, при этом приемлемые цены и нет лишней пафосности. Пока я была там — то и дело поступали звонки с заказами, приходили и уходили курьеры, — из чего можно сделать вывод об известности и востребованности заведения у местных. Попала к ним случайно, просто проходя мимо, не пожалела.',
  },
];

const NAV_LINKS = [
  { id: 'overview', label: 'Обзор' },
  { id: 'menu', label: 'Меню' },
  { id: 'reviews', label: 'Отзывы' },
  { id: 'info', label: 'Информация' },
];

function StarRating({ rating, size = 16 }: { rating: number; size?: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          size={size}
          className={i <= Math.round(rating) ? 'fill-current' : ''}
          style={{ color: i <= Math.round(rating) ? 'var(--color-golden)' : '#d1d5db' }}
        />
      ))}
    </div>
  );
}

export default function App() {
  const [bookingOpen, setBookingOpen] = useState(false);
  const [navScrolled, setNavScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const onScroll = () => setNavScrolled(window.scrollY > 60);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    setMobileMenuOpen(false);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Кафе «Блинный домик»',
          text: 'Кафе «Блинный домик» — ул. Абая 25, Петропавловск',
          url: window.location.href,
        });
      } catch { /* user cancelled */ }
    } else {
      try {
        await navigator.clipboard.writeText(window.location.href);
        alert('Ссылка скопирована в буфер обмена');
      } catch { /* ignore */ }
    }
  };

  const handleRoute = () => {
    window.open('https://www.google.com/maps/search/?api=1&query=ул.+Абая+25+Петропавловск', '_blank');
  };

  return (
    <div className="min-h-screen" style={{ background: 'var(--color-cream)' }}>
      {/* === Navigation === */}
      <nav
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 ${
          navScrolled ? 'py-2.5 shadow-lg' : 'py-4'
        }`}
        style={{
          background: navScrolled ? 'rgba(250, 246, 240, 0.95)' : 'rgba(43, 33, 24, 0.25)',
          backdropFilter: 'blur(12px)',
        }}
      >
        <div className="max-w-7xl mx-auto px-5 flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-2.5 cursor-pointer btn-hover" onClick={() => scrollToSection('hero')}>
            <div
              className="w-9 h-9 rounded-full flex items-center justify-center"
              style={{ background: 'var(--color-golden)' }}
            >
              <UtensilsCrossed size={18} className="text-white" />
            </div>
            <span
              className="text-lg font-bold tracking-tight transition-colors duration-300"
              style={{ color: navScrolled ? 'var(--color-dark)' : '#fff' }}
            >
              Блинный домик
            </span>
          </div>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-7">
            {NAV_LINKS.map((link) => (
              <button
                key={link.id}
                onClick={() => scrollToSection(link.id)}
                className="nav-link text-sm font-medium transition-colors duration-300"
                style={{ color: navScrolled ? 'var(--color-mocha)' : 'rgba(255,255,255,0.9)' }}
              >
                {link.label}
              </button>
            ))}
            <button
              onClick={() => setBookingOpen(true)}
              className="btn-primary-hover px-6 py-2.5 rounded-full text-white text-sm font-semibold"
              style={{ background: 'linear-gradient(135deg, #c87f2a, #e0a83b)' }}
            >
              Забронировать
            </button>
          </div>

          {/* Mobile toggle */}
          <button
            className="md:hidden btn-hover"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            style={{ color: navScrolled ? 'var(--color-dark)' : '#fff' }}
            aria-label="Меню"
          >
            {mobileMenuOpen ? <X size={24} /> : <MenuIcon size={24} />}
          </button>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden overlay-in mt-2 mx-4 rounded-xl p-4 shadow-xl" style={{ background: 'rgba(250,246,240,0.98)' }}>
            <div className="flex flex-col gap-3">
              {NAV_LINKS.map((link) => (
                <button
                  key={link.id}
                  onClick={() => scrollToSection(link.id)}
                  className="text-left py-2 text-sm font-medium btn-hover"
                  style={{ color: 'var(--color-mocha)' }}
                >
                  {link.label}
                </button>
              ))}
              <button
                onClick={() => { setBookingOpen(true); setMobileMenuOpen(false); }}
                className="btn-primary-hover py-3 rounded-full text-white text-sm font-semibold mt-2"
                style={{ background: 'linear-gradient(135deg, #c87f2a, #e0a83b)' }}
              >
                Забронировать
              </button>
            </div>
          </div>
        )}
      </nav>

      {/* === Hero === */}
      <section id="hero" className="relative h-screen flex items-center justify-center overflow-hidden" style={{ background: 'linear-gradient(135deg, #c87f2a, #e0a83b)' }}>
        {/* Background image */}
        <div className="absolute inset-0">
          <img
            src={HERO_IMAGE}
            alt="Стопка золотистых блинов с сиропом"
            className="hero-image w-full h-full object-cover"
            onError={(e) => { (e.currentTarget.style as any).display = 'none'; }}
          />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(180deg, rgba(43,33,24,0.45) 0%, rgba(43,33,24,0.35) 40%, rgba(43,33,24,0.7) 100%)' }} />
        </div>

        {/* Content */}
        <div className="relative z-10 text-center px-5 max-w-3xl">
          <div
            className="reveal reveal-fade-down active mb-4 inline-flex items-center gap-2 px-4 py-1.5 rounded-full"
            style={{ background: 'rgba(255,255,255,0.15)', backdropFilter: 'blur(8px)', animationDelay: '200ms' }}
          >
            <Star size={16} className="fill-current" style={{ color: 'var(--color-golden)' }} />
            <span className="text-white text-sm font-medium">4,3 · 342 отзыва</span>
            <span className="text-white/50">|</span>
            <span className="text-white/80 text-sm">2 000–4 000 ₸</span>
          </div>

          <h1
            className="reveal reveal-fade-up active text-5xl md:text-7xl font-bold text-white mb-4 leading-tight"
            style={{ animationDelay: '400ms', textShadow: '0 4px 20px rgba(0,0,0,0.4)' }}
          >
            Блинный домик
          </h1>

          <p
            className="reveal reveal-fade-up active text-lg md:text-xl text-white/90 mb-8 font-light"
            style={{ animationDelay: '600ms', textShadow: '0 2px 10px rgba(0,0,0,0.3)' }}
          >
            Кафе · ул. Абая 25, Петропавловск
          </p>

          <div
            className="reveal reveal-fade-up active flex flex-wrap items-center justify-center gap-3"
            style={{ animationDelay: '800ms' }}
          >
            <button
              onClick={() => setBookingOpen(true)}
              className="btn-primary-hover px-8 py-3.5 rounded-full text-white font-semibold text-base"
              style={{ background: 'linear-gradient(135deg, #c87f2a, #e0a83b)', boxShadow: '0 8px 25px rgba(200,127,42,0.4)' }}
            >
              <span className="flex items-center gap-2">
                <Calendar size={18} />
                Забронировать
              </span>
            </button>
            <button
              onClick={() => scrollToSection('menu')}
              className="btn-hover px-7 py-3.5 rounded-full text-white font-medium text-base border border-white/30"
              style={{ background: 'rgba(255,255,255,0.1)', backdropFilter: 'blur(8px)' }}
            >
              Смотреть меню
            </button>
          </div>

          {/* Status badge */}
          <div
            className="reveal reveal-fade active mt-8 inline-flex items-center gap-2 text-sm text-white/80"
            style={{ animationDelay: '1000ms' }}
          >
            <span className="w-2 h-2 rounded-full" style={{ background: '#4ade80', boxShadow: '0 0 8px #4ade80' }} />
            Открыто · Закроется в 23:00
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-1">
          <span className="text-white/50 text-xs uppercase tracking-widest">Листайте вниз</span>
          <div className="w-6 h-10 rounded-full border-2 border-white/30 flex items-start justify-center pt-2">
            <div className="scroll-dot w-1.5 h-1.5 rounded-full bg-white/70" />
          </div>
        </div>
      </section>

      {/* === Action buttons bar === */}
      <section className="sticky top-0 z-30 border-b border-gray-200/60" style={{ background: 'rgba(250,246,240,0.95)', backdropFilter: 'blur(10px)' }}>
        <div className="max-w-7xl mx-auto px-5 py-3 flex items-center gap-2 overflow-x-auto no-scrollbar">
          {[
            { icon: Navigation, label: 'Проложить маршрут', onClick: handleRoute },
            { icon: Bookmark, label: saved ? 'Сохранено' : 'Сохранить', onClick: () => setSaved(!saved) },
            { icon: Share2, label: 'Поделиться', onClick: handleShare },
          ].map((btn, i) => (
            <button
              key={i}
              onClick={btn.onClick}
              className="btn-hover flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap border border-gray-200 hover:border-gray-300"
              style={{ background: '#fff', color: 'var(--color-dark)' }}
            >
              <btn.icon size={16} style={{ color: 'var(--color-amber)' }} />
              {btn.label}
            </button>
          ))}
        </div>
      </section>

      {/* === Overview === */}
      <section id="overview" className="max-w-7xl mx-auto px-5 py-20">
        <Reveal variant="fade-up">
          <div className="text-center mb-12">
            <span className="text-sm font-semibold uppercase tracking-widest" style={{ color: 'var(--color-amber)' }}>
              Кафе
            </span>
            <h2 className="text-4xl md:text-5xl font-bold mt-2 mb-4" style={{ color: 'var(--color-dark)' }}>
              Обзор
            </h2>
            <p className="text-base max-w-2xl mx-auto" style={{ color: 'var(--color-mocha)', lineHeight: 1.7 }}>
              Уютное домашнее кафе в сердце Петропавловска. Вкусные блины, сырники и торты на заказ —
              всё приготовлено без химии, по-домашнему. Отличное место для семейного обеда, встречи с друзьями
              или праздника.
            </p>
          </div>
        </Reveal>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {[
            { icon: Star, value: '4,3', label: 'Средняя оценка', sub: '342 отзыва' },
            { icon: Users, value: '2–4 тыс ₸', label: 'На человека', sub: 'Информация от 8 человек' },
            { icon: Clock, value: 'до 23:00', label: 'Часы работы', sub: 'Открыто сейчас' },
            { icon: Award, value: 'Топ кафе', label: 'Петропавловск', sub: 'Домашняя кухня' },
          ].map((stat, i) => (
            <Reveal key={i} variant="scale" delay={i * 100}>
              <div className="card-hover bg-white rounded-2xl p-5 md:p-6 text-center border border-gray-100">
                <div className="mx-auto mb-3 w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: 'var(--color-warm)' }}>
                  <stat.icon size={22} style={{ color: 'var(--color-amber)' }} />
                </div>
                <div className="text-xl font-bold" style={{ color: 'var(--color-dark)' }}>{stat.value}</div>
                <div className="text-sm mt-0.5" style={{ color: 'var(--color-mocha)' }}>{stat.label}</div>
                <div className="text-xs mt-0.5 text-gray-400">{stat.sub}</div>
              </div>
            </Reveal>
          ))}
        </div>

        {/* Services */}
        <Reveal variant="fade-up" delay={200}>
          <div className="mt-12 flex flex-wrap justify-center gap-3">
            {[
              { icon: UtensilsCrossed, label: 'Еда в заведении' },
              { icon: ShoppingBag, label: 'Еда навынос' },
              { icon: Heart, label: 'Праздники на заказ' },
            ].map((s, i) => (
              <div
                key={i}
                className="btn-hover flex items-center gap-2 px-5 py-3 rounded-full"
                style={{ background: 'var(--color-warm)' }}
              >
                <s.icon size={18} style={{ color: 'var(--color-amber)' }} />
                <span className="text-sm font-medium" style={{ color: 'var(--color-dark)' }}>{s.label}</span>
              </div>
            ))}
          </div>
        </Reveal>
      </section>

      {/* === Menu === */}
      <section id="menu" className="py-20" style={{ background: 'var(--color-warm)' }}>
        <div className="max-w-7xl mx-auto px-5">
          <Reveal variant="fade-up">
            <div className="text-center mb-12">
              <span className="text-sm font-semibold uppercase tracking-widest" style={{ color: 'var(--color-amber)' }}>
                Меню
              </span>
              <h2 className="text-4xl md:text-5xl font-bold mt-2" style={{ color: 'var(--color-dark)' }}>
                Наши блюда
              </h2>
            </div>
          </Reveal>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
            {MENU_ITEMS.map((item, i) => (
              <Reveal key={i} variant={i % 2 === 0 ? 'left' : 'right'} delay={(i % 2) * 100}>
                <div className="card-hover bg-white rounded-2xl p-5 md:p-6 border border-gray-100 h-full">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--color-dark)' }}>
                        {item.name}
                      </h3>
                      <p className="text-sm mb-3" style={{ color: 'var(--color-mocha)' }}>
                        {item.desc}
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {item.tags.map((tag, j) => (
                          <span
                            key={j}
                            className="text-xs px-2.5 py-1 rounded-full"
                            style={{ background: 'var(--color-warm)', color: 'var(--color-mocha)' }}
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="text-lg font-bold" style={{ color: 'var(--color-amber)' }}>
                        {item.price}
                      </span>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal variant="fade-up" delay={200}>
            <div className="text-center mt-10">
              <button
                onClick={() => setBookingOpen(true)}
                className="btn-primary-hover px-8 py-3.5 rounded-full text-white font-semibold"
                style={{ background: 'linear-gradient(135deg, #c87f2a, #e0a83b)' }}
              >
                Забронировать столик
              </button>
            </div>
          </Reveal>
        </div>
      </section>

      {/* === Reviews === */}
      <section id="reviews" className="max-w-7xl mx-auto px-5 py-20">
        <Reveal variant="fade-up">
          <div className="text-center mb-12">
            <span className="text-sm font-semibold uppercase tracking-widest" style={{ color: 'var(--color-amber)' }}>
              Отзывы
            </span>
            <h2 className="text-4xl md:text-5xl font-bold mt-2 mb-4" style={{ color: 'var(--color-dark)' }}>
              Что говорят гости
            </h2>
          </div>
        </Reveal>

        {/* Rating summary */}
        <Reveal variant="scale">
          <div className="bg-white rounded-2xl p-6 md:p-8 border border-gray-100 mb-8 flex flex-col md:flex-row items-center gap-6">
            <div className="text-center">
              <div className="text-5xl font-bold" style={{ color: 'var(--color-dark)' }}>4,3</div>
              <StarRating rating={4.3} size={20} />
              <div className="text-sm mt-1" style={{ color: 'var(--color-mocha)' }}>342 отзыва</div>
            </div>
            <div className="flex-1 w-full space-y-1.5">
              {[
                { star: 5, pct: 70 },
                { star: 4, pct: 18 },
                { star: 3, pct: 7 },
                { star: 2, pct: 3 },
                { star: 1, pct: 2 },
              ].map((row) => (
                <div key={row.star} className="flex items-center gap-2">
                  <span className="text-xs w-3" style={{ color: 'var(--color-mocha)' }}>{row.star}</span>
                  <Star size={12} className="fill-current" style={{ color: 'var(--color-golden)' }} />
                  <div className="flex-1 h-2 rounded-full overflow-hidden" style={{ background: '#f0e8db' }}>
                    <div
                      className="h-full rounded-full transition-all duration-1000"
                      style={{ width: `${row.pct}%`, background: 'linear-gradient(90deg, #e0a83b, #c87f2a)' }}
                    />
                  </div>
                  <span className="text-xs w-8 text-right" style={{ color: 'var(--color-mocha)' }}>{row.pct}%</span>
                </div>
              ))}
            </div>
          </div>
        </Reveal>

        {/* Reviews carousel */}
        <Reveal variant="fade-up">
          <ReviewsCarousel reviews={REVIEWS} />
        </Reveal>
      </section>

      {/* === Info === */}
      <section id="info" className="py-20" style={{ background: 'var(--color-warm)' }}>
        <div className="max-w-5xl mx-auto px-5">
          <Reveal variant="fade-up">
            <div className="text-center mb-12">
              <span className="text-sm font-semibold uppercase tracking-widest" style={{ color: 'var(--color-amber)' }}>
                Информация
              </span>
              <h2 className="text-4xl md:text-5xl font-bold mt-2" style={{ color: 'var(--color-dark)' }}>
                Как нас найти
              </h2>
            </div>
          </Reveal>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
            <Reveal variant="left">
              <div className="card-hover bg-white rounded-2xl p-6 border border-gray-100 h-full">
                <div className="flex items-start gap-4">
                  <div className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0" style={{ background: 'var(--color-warm)' }}>
                    <MapPin size={20} style={{ color: 'var(--color-amber)' }} />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1" style={{ color: 'var(--color-dark)' }}>Адрес</h4>
                    <p className="text-sm" style={{ color: 'var(--color-mocha)' }}>ул. Абая 25, Петропавловск 150000</p>
                    <p className="text-xs mt-1 text-gray-400">V4FP+XW Петропавловск</p>
                    <button
                      onClick={handleRoute}
                      className="btn-hover mt-3 inline-flex items-center gap-1.5 text-sm font-medium"
                      style={{ color: 'var(--color-amber)' }}
                    >
                      <Navigation size={15} /> Проложить маршрут
                    </button>
                  </div>
                </div>
              </div>
            </Reveal>

            <Reveal variant="right">
              <div className="card-hover bg-white rounded-2xl p-6 border border-gray-100 h-full">
                <div className="flex items-start gap-4">
                  <div className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0" style={{ background: 'var(--color-warm)' }}>
                    <Clock size={20} style={{ color: 'var(--color-amber)' }} />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1" style={{ color: 'var(--color-dark)' }}>Часы работы</h4>
                    <p className="text-sm flex items-center gap-2" style={{ color: 'var(--color-mocha)' }}>
                      <span className="w-2 h-2 rounded-full" style={{ background: '#4ade80' }} />
                      Открыто · Закроется в 23:00
                    </p>
                    <p className="text-xs mt-2 text-gray-400">Посещаемость: по воскресеньям</p>
                  </div>
                </div>
              </div>
            </Reveal>

            <Reveal variant="left" delay={100}>
              <div className="card-hover bg-white rounded-2xl p-6 border border-gray-100 h-full">
                <div className="flex items-start gap-4">
                  <div className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0" style={{ background: 'var(--color-warm)' }}>
                    <Phone size={20} style={{ color: 'var(--color-amber)' }} />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1" style={{ color: 'var(--color-dark)' }}>Телефон</h4>
                    <a
                      href="tel:+77152467026"
                      className="btn-hover text-sm font-medium block"
                      style={{ color: 'var(--color-amber)' }}
                    >
                      8 (7152) 46 70 26
                    </a>
                    <p className="text-xs mt-1 text-gray-400">Звоните для заказа</p>
                  </div>
                </div>
              </div>
            </Reveal>

            <Reveal variant="right" delay={100}>
              <div className="card-hover bg-white rounded-2xl p-6 border border-gray-100 h-full">
                <div className="flex items-start gap-4">
                  <div className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0" style={{ background: 'var(--color-warm)' }}>
                    <UtensilsCrossed size={20} style={{ color: 'var(--color-amber)' }} />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-1" style={{ color: 'var(--color-dark)' }}>Услуги</h4>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {['Еда в заведении', 'Еда навынос', 'Торты на заказ'].map((s) => (
                        <span key={s} className="text-xs px-2.5 py-1 rounded-full" style={{ background: 'var(--color-warm)', color: 'var(--color-mocha)' }}>
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* === Footer === */}
      <footer className="py-12 px-5" style={{ background: 'var(--color-dark)' }}>
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex items-center justify-center gap-2.5 mb-4">
            <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: 'var(--color-golden)' }}>
              <UtensilsCrossed size={18} className="text-white" />
            </div>
            <span className="text-lg font-bold text-white">Блинный домик</span>
          </div>
          <p className="text-sm text-white/50 mb-6 max-w-md mx-auto">
            Кафе домашней кухни · ул. Абая 25, Петропавловск 150000
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => setBookingOpen(true)}
              className="btn-primary-hover px-6 py-2.5 rounded-full text-white text-sm font-semibold"
              style={{ background: 'linear-gradient(135deg, #c87f2a, #e0a83b)' }}
            >
              Забронировать
            </button>
            <button
              onClick={handleRoute}
              className="btn-hover px-5 py-2.5 rounded-full text-sm font-medium border border-white/20 text-white/80"
            >
              Маршрут
            </button>
            <button
              onClick={handleShare}
              className="btn-hover px-5 py-2.5 rounded-full text-sm font-medium border border-white/20 text-white/80"
            >
              Поделиться
            </button>
          </div>
          <p className="text-xs text-white/30 mt-8">© 2026 Кафе «Блинный домик»</p>
        </div>
      </footer>

      {/* === Booking Modal === */}
      <BookingModal open={bookingOpen} onClose={() => setBookingOpen(false)} />
    </div>
  );
}
