import { useState } from 'react';
import {
  ArrowLeft, UtensilsCrossed, Coffee, Briefcase, Clock,
  Flame, Soup, Salad, Croissant,
} from 'lucide-react';

type Category = 'breakfast' | 'business' | 'blini' | 'hot' | 'soups' | 'salads' | 'snacks';

interface Dish {
  name: string;
  desc: string;
  price: string;
  tags?: string[];
  items?: string[];
  section?: string;
}

const MENU: Record<Category, { title: string; icon: typeof UtensilsCrossed; image: string; dishes: Dish[] }> = {
  breakfast: {
    title: 'Завтраки',
    icon: Coffee,
    image: 'https://images.pexels.com/photos/4966595/pexels-photo-4966595.jpeg?auto=compress&cs=tinysrgb&w=1920',
    dishes: [
      {
        name: 'Завтрак 1',
        desc: 'Сытный завтрак на весь день',
        price: '3200 ₸',
        items: ['Глазунья (2 яйца)', 'Драники (3 шт)', 'Колбаски (2 шт)', 'Овощной салат', 'Фасоль в красном соусе', 'Чай'],
      },
      {
        name: 'Завтрак 2',
        desc: 'Куриные оладьи и блинчики с моцареллой',
        price: '3200 ₸',
        items: ['Глазунья (2 яйца)', 'Куриные оладьи (2 шт)', 'Блинчики с моцареллой (2 шт)', 'Овощной салат', 'Фасоль в красном соусе', 'Чай'],
      },
      {
        name: 'Завтрак 3',
        desc: 'Овсяная каша, сырники и блинчики',
        price: '3000 ₸',
        items: ['Каша овсяная с орехами и сухофруктами', 'Сырники кокосовые со сгущенкой (3 шт)', 'Блинчики с яблоком и корицей (2 шт)', 'Чай'],
      },
      {
        name: 'Завтрак 4',
        desc: 'Сёмга слабой соли с греческим салатом',
        price: '3500 ₸',
        items: ['Вареные яйца (2 шт)', 'Семга слабой соли', 'Греческий салат', 'Блинчики (3 шт)', 'Чай'],
      },
      {
        name: 'Сет из блинчиков',
        desc: 'Четыре вида блинчиков с соусами',
        price: '3200 ₸',
        items: ['Блинчики с ветчиной и сыром (2 шт)', 'Блинчики по-мексикански (2 шт)', 'Блинчики с зелёным луком и яйцом (2 шт)', 'Блинчики (5 шт)', 'Сметана, грибной соус, соус сладкий чили'],
      },
    ],
  },
  business: {
    title: 'Бизнес-ланчи',
    icon: Briefcase,
    image: 'https://images.pexels.com/photos/163018/food-business-lunch-restaurant-lunch-163018.jpeg?auto=compress&cs=tinysrgb&w=1920',
    dishes: [
      {
        name: 'Обед 1',
        desc: 'Окрошка, куриные оладьи с пюре, блинчики',
        price: '2900 ₸',
        items: ['Окрошка с куриной ветчиной', 'Оладьи куриные с пюре', 'Блинчики со сметаной', 'Чай'],
      },
      {
        name: 'Обед 2',
        desc: 'Суп лапша, битые огурцы, жареная рыба',
        price: '2900 ₸',
        items: ['Суп лапша', 'Битые огурцы', 'Рыба жареная с картофельным пюре', 'Чай'],
      },
      {
        name: 'Обед 3',
        desc: 'Греческий салат, лагман, блинчики со сгущёнкой',
        price: '2900 ₸',
        items: ['Салат греческий', 'Лагман', 'Блинчики со сгущенкой', 'Чай'],
      },
      {
        name: 'Обед 4',
        desc: 'Солянка, утиная грудка с чечевичным пюре',
        price: '2900 ₸',
        items: ['Солянка', 'Утиная грудка с чечевичным пюре', 'Блинчики с джемом', 'Чай'],
      },
    ],
  },
  hot: {
    title: 'Горячие блюда',
    icon: Flame,
    image: 'https://images.pexels.com/photos/36734923/pexels-photo-36734923.jpeg?auto=compress&cs=tinysrgb&w=1920',
    dishes: [],
  },
  soups: {
    title: 'Супы',
    icon: Soup,
    image: 'https://images.pexels.com/photos/29007237/pexels-photo-29007237.jpeg?auto=compress&cs=tinysrgb&w=1920',
    dishes: [],
  },
  salads: {
    title: 'Салаты',
    icon: Salad,
    image: 'https://images.pexels.com/photos/842545/pexels-photo-842545.jpeg?auto=compress&cs=tinysrgb&w=1920',
    dishes: [],
  },
  snacks: {
    title: 'Горячие закуски',
    icon: Croissant,
    image: 'https://images.pexels.com/photos/5639416/pexels-photo-5639416.jpeg?auto=compress&cs=tinysrgb&w=1920',
    dishes: [],
  },
  blini: {
    title: 'Блины',
    icon: UtensilsCrossed,
    image: 'https://images.pexels.com/photos/574111/pexels-photo-574111.jpeg?auto=compress&cs=tinysrgb&w=1920',
    dishes: [
      { name: 'Сладкие блинчики', desc: '', price: '', section: 'СЛАДКИЕ БЛИНЧИКИ' },
      { name: 'Блинчики с творогом', desc: '', price: '1000 ₸', section: 'СЛАДКИЕ БЛИНЧИКИ' },
      { name: 'Блинный яблочный штрудель', desc: '', price: '1000 ₸', section: 'СЛАДКИЕ БЛИНЧИКИ' },
      { name: 'Блинчики с горячей ягодой', desc: '', price: '1200 ₸', section: 'СЛАДКИЕ БЛИНЧИКИ' },
      { name: 'Блинчики с мороженым и бананом', desc: '', price: '1300 ₸', section: 'СЛАДКИЕ БЛИНЧИКИ' },
      { name: 'Блинчики Синнабон', desc: '', price: '1300 ₸', section: 'СЛАДКИЕ БЛИНЧИКИ' },
      { name: 'Блинчики Орео', desc: '', price: '1300 ₸', tags: ['New'], section: 'СЛАДКИЕ БЛИНЧИКИ' },
      { name: 'Блинчики мамины', desc: '', price: '1300 ₸', section: 'СЛАДКИЕ БЛИНЧИКИ' },
      { name: 'Блинчики со сметаной/сгущ. молоком/мёдом/джемом', desc: '', price: '550 ₸', section: 'СЛАДКИЕ БЛИНЧИКИ' },

      { name: 'Сытные блинчики', desc: '', price: '', section: 'СЫТНЫЕ БЛИНЧИКИ' },
      { name: 'Блинчатые ракушки с красной рыбой', desc: '', price: '1700 ₸', section: 'СЫТНЫЕ БЛИНЧИКИ' },
      { name: 'Блинные роллы с красной рыбой', desc: '', price: '1700 ₸', section: 'СЫТНЫЕ БЛИНЧИКИ' },
      { name: 'Блинчики с мясным фаршем и рисом', desc: '', price: '1000 ₸', section: 'СЫТНЫЕ БЛИНЧИКИ' },
      { name: 'Блинчики с зелёным луком и яйцом', desc: '', price: '1000 ₸', section: 'СЫТНЫЕ БЛИНЧИКИ' },
      { name: 'Блинчики с ветчиной и сыром', desc: '', price: '1100 ₸', section: 'СЫТНЫЕ БЛИНЧИКИ' },
      { name: 'Блинчики с куриным жульеном', desc: '', price: '1200 ₸', section: 'СЫТНЫЕ БЛИНЧИКИ' },
      { name: 'Блинное хачапури', desc: '', price: '1200 ₸', section: 'СЫТНЫЕ БЛИНЧИКИ' },
      { name: 'Блинчики с копчёной уткой, томатами и моцареллой', desc: '', price: '1300 ₸', section: 'СЫТНЫЕ БЛИНЧИКИ' },
      { name: 'Блинная пицца', desc: '', price: '1300 ₸', section: 'СЫТНЫЕ БЛИНЧИКИ' },
      { name: 'Блинчики по-мексикански', desc: '', price: '1300 ₸', tags: ['New'], section: 'СЫТНЫЕ БЛИНЧИКИ' },
      { name: 'Блинчики', desc: '', price: '90 ₸/шт', section: 'СЫТНЫЕ БЛИНЧИКИ' },
    ],
  },
};

const CATEGORY_ORDER: Category[] = ['breakfast', 'business', 'blini', 'hot', 'soups', 'salads', 'snacks'];

interface MenuPageProps {
  onBack: () => void;
}

export default function MenuPage({ onBack }: MenuPageProps) {
  const [active, setActive] = useState<Category>('breakfast');
  const cat = MENU[active];

  return (
    <div className="min-h-screen" style={{ background: 'var(--color-cream)' }}>
      {/* Header banner */}
      <div className="relative h-72 md:h-80 overflow-hidden">
        <img src={cat.image} alt={cat.title} className="w-full h-full object-cover transition-opacity duration-500" />
        <div className="absolute inset-0" style={{ background: 'linear-gradient(180deg, rgba(43,33,24,0.4) 0%, rgba(43,33,24,0.75) 100%)' }} />
        <div className="absolute inset-0 flex flex-col">
          <div className="max-w-6xl mx-auto w-full px-5 pt-6 flex items-center justify-between">
            <button
              onClick={onBack}
              className="btn-hover flex items-center gap-2 px-4 py-2 rounded-full text-white text-sm font-medium"
              style={{ background: 'rgba(255,255,255,0.15)', backdropFilter: 'blur(8px)' }}
            >
              <ArrowLeft size={16} />
              Назад
            </button>
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: 'var(--color-golden)' }}>
                <UtensilsCrossed size={18} className="text-white" />
              </div>
              <span className="text-lg font-bold text-white">Блинный домик</span>
            </div>
          </div>
          <div className="flex-1 flex flex-col items-center justify-center text-center px-5">
            <span className="text-sm font-semibold uppercase tracking-widest text-white/70 mb-2">Полное меню</span>
            <h1 className="text-4xl md:text-5xl font-bold text-white" style={{ textShadow: '0 4px 20px rgba(0,0,0,0.4)' }}>
              {cat.title}
            </h1>
          </div>
        </div>
      </div>

      {/* Category tabs */}
      <div className="sticky top-0 z-30 border-b border-gray-200/60" style={{ background: 'rgba(250,246,240,0.95)', backdropFilter: 'blur(10px)' }}>
        <div className="max-w-6xl mx-auto px-5 py-3 flex items-center gap-2 overflow-x-auto no-scrollbar">
          {CATEGORY_ORDER.map((key) => {
            const c = MENU[key];
            const isActive = key === active;
            return (
              <button
                key={key}
                onClick={() => setActive(key)}
                className={`btn-hover flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-semibold whitespace-nowrap transition-all duration-300 ${
                  isActive ? 'text-white' : ''
                }`}
                style={isActive ? { background: 'linear-gradient(135deg, #c87f2a, #e0a83b)' } : { background: '#fff', color: 'var(--color-mocha)', border: '1px solid #e5e0d6' }}
              >
                <c.icon size={16} style={isActive ? { color: '#fff' } : { color: 'var(--color-amber)' }} />
                {c.title}
              </button>
            );
          })}
        </div>
      </div>

      {/* Dish list */}
      <div className="max-w-6xl mx-auto px-5 py-12">
        <div className="flex items-center gap-3 mb-8">
          <cat.icon size={28} style={{ color: 'var(--color-amber)' }} />
          <div>
            <h2 className="text-2xl font-bold" style={{ color: 'var(--color-dark)' }}>{cat.title}</h2>
            <p className="text-sm flex items-center gap-1.5" style={{ color: 'var(--color-mocha)' }}>
              <Clock size={14} />
              {cat.dishes.length} блюд в категории
            </p>
          </div>
        </div>

        {cat.dishes.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
          {cat.dishes.map((dish, i) => {
            const isHeader = dish.section && dish.price === '' && dish.desc === '' && dish.name === dish.section;
            if (isHeader) {
              return (
                <div key={i} className="col-span-full mt-6 first:mt-0">
                  <h3 className="text-xl font-bold tracking-wide" style={{ color: 'var(--color-amber)' }}>
                    {dish.section}
                  </h3>
                  <div className="mt-2 h-px" style={{ background: 'linear-gradient(90deg, var(--color-amber), transparent)' }} />
                </div>
              );
            }
            return (
            <div
              key={i}
              className="card-hover bg-white rounded-2xl p-5 md:p-6 border border-gray-100"
              style={{ animation: `fadeUp 0.5s ease ${i * 60}ms both` }}
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--color-dark)' }}>
                    {dish.name}
                  </h3>
                  {dish.desc && (
                  <p className="text-sm mb-3" style={{ color: 'var(--color-mocha)' }}>
                    {dish.desc}
                  </p>
                  )}
                  {dish.items && (
                    <ul className="space-y-1.5 mb-3">
                      {dish.items.map((item, k) => (
                        <li key={k} className="flex items-center gap-2 text-sm" style={{ color: 'var(--color-mocha)' }}>
                          <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: 'var(--color-amber)' }} />
                          {item}
                        </li>
                      ))}
                    </ul>
                  )}
                  {dish.tags && (
                    <div className="flex flex-wrap gap-1.5">
                      {dish.tags.map((tag, j) => (
                        <span
                          key={j}
                          className="text-xs px-2.5 py-1 rounded-full"
                          style={{ background: 'var(--color-warm)', color: 'var(--color-mocha)' }}
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <div className="text-right shrink-0">
                  <span className="text-lg font-bold" style={{ color: 'var(--color-amber)' }}>
                    {dish.price}
                  </span>
                </div>
              </div>
            </div>
            );
          })}
        </div>
        ) : (
          <div className="text-center py-16">
            <cat.icon size={48} className="mx-auto mb-4 opacity-30" style={{ color: 'var(--color-mocha)' }} />
            <p className="text-lg font-medium" style={{ color: 'var(--color-mocha)' }}>
              Меню скоро будет добавлено
            </p>
            <p className="text-sm mt-1" style={{ color: 'var(--color-mocha)', opacity: 0.6 }}>
              Мы готовим эту категорию для вас
            </p>
          </div>
        )}

        <div className="text-center mt-12">
          <button
            onClick={onBack}
            className="btn-hover px-7 py-3.5 rounded-full text-white font-semibold"
            style={{ background: 'linear-gradient(135deg, #c87f2a, #e0a83b)' }}
          >
            <span className="flex items-center gap-2 justify-center">
              <ArrowLeft size={18} />
              Вернуться на главную
            </span>
          </button>
        </div>
      </div>

      <footer className="py-10 px-5 text-center" style={{ background: 'var(--color-dark)' }}>
        <p className="text-sm text-white/50">
          Кафе «Блинный домик» · ул. Абая 25, Петропавловск · 8 (7152) 46 70 26
        </p>
        <p className="text-xs text-white/30 mt-2">© 2026 Кафе «Блинный домик»</p>
      </footer>
    </div>
  );
}
