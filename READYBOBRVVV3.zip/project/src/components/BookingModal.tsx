import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { X, Calendar, Users, Phone, User, Clock, CheckCircle2, Loader2, MessageCircle } from 'lucide-react';

interface BookingModalProps {
  open: boolean;
  onClose: () => void;
}

const WHATSAPP_NUMBER = '77752728282';

const TIME_SLOTS = [
  '09:00', '10:00', '11:00', '12:00', '13:00',
  '14:00', '15:00', '16:00', '17:00', '18:00',
  '19:00', '20:00', '21:00', '22:00',
];

export default function BookingModal({ open, onClose }: BookingModalProps) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [guests, setGuests] = useState(2);
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [comment, setComment] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  if (!open) return null;

  const today = new Date().toISOString().split('T')[0];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !date || !time) {
      setStatus('error');
      setErrorMsg('Пожалуйста, заполните все обязательные поля');
      return;
    }

    setStatus('loading');
    setErrorMsg('');

    const { error } = await supabase.from('bookings').insert({
      name: name.trim(),
      phone: phone.trim(),
      guests,
      booking_date: date,
      booking_time: time,
      comment: comment.trim() || null,
    });

    if (error) {
      setStatus('error');
      setErrorMsg('Не удалось отправить заявку. Попробуйте ещё раз.');
      return;
    }

    const lines = [
      `Новое бронирование «Блинный домик»`,
      `Имя: ${name.trim()}`,
      `Телефон: ${phone.trim()}`,
      `Гости: ${guests}`,
      `Дата: ${date}`,
      `Время: ${time}`,
    ];
    if (comment.trim()) lines.push(`Комментарий: ${comment.trim()}`);
    const waText = encodeURIComponent(lines.join('\n'));
    const waUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${waText}`;
    window.open(waUrl, '_blank', 'noopener,noreferrer');

    setStatus('success');
  };

  const handleClose = () => {
    setStatus('idle');
    setName('');
    setPhone('');
    setGuests(2);
    setDate('');
    setTime('');
    setComment('');
    setErrorMsg('');
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 overlay-in"
      style={{ background: 'rgba(43, 33, 24, 0.6)', backdropFilter: 'blur(4px)' }}
      onClick={handleClose}
    >
      <div
        className="modal-in w-full max-w-md rounded-2xl bg-white shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
        style={{ maxHeight: '90vh', overflowY: 'auto' }}
      >
        {/* Header */}
        <div className="relative px-6 py-5" style={{ background: 'linear-gradient(135deg, #c87f2a, #e0a83b)' }}>
          <button
            onClick={handleClose}
            className="btn-hover absolute top-4 right-4 text-white/80 hover:text-white"
            aria-label="Закрыть"
          >
            <X size={22} />
          </button>
          <h2 className="text-2xl font-bold text-white">Забронировать столик</h2>
          <p className="text-white/80 text-sm mt-1">Кафе «Блинный домик»</p>
        </div>

        {status === 'success' ? (
          <div className="px-6 py-10 text-center">
            <div className="mx-auto mb-4 w-16 h-16 rounded-full flex items-center justify-center" style={{ background: '#e8f5e9' }}>
              <CheckCircle2 size={36} style={{ color: '#4caf50' }} />
            </div>
            <h3 className="text-xl font-semibold mb-2" style={{ color: 'var(--color-dark)' }}>
              Заявка отправлена!
            </h3>
            <p className="text-sm mb-4" style={{ color: 'var(--color-mocha)' }}>
              Мы свяжемся с вами по телефону для подтверждения брони.
            </p>
            <a
              href={`https://wa.me/${WHATSAPP_NUMBER}`}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary-hover inline-flex items-center justify-center gap-2 px-6 py-3 rounded-full text-white font-medium mb-3"
              style={{ background: '#25D366' }}
            >
              <MessageCircle size={20} />
              Написать в WhatsApp
            </a>
            <div>
              <button
                onClick={handleClose}
                className="btn-primary-hover px-8 py-3 rounded-full text-white font-medium"
                style={{ background: 'var(--color-amber)' }}
              >
                Готово
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="px-6 py-5 space-y-4">
            {/* Name */}
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--color-mocha)' }}>
                Имя *
              </label>
              <div className="relative">
                <User size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ваше имя"
                  className="input-focus w-full pl-10 pr-4 py-2.5 rounded-lg border border-gray-200 outline-none"
                  style={{ fontSize: '15px' }}
                />
              </div>
            </div>

            {/* Phone */}
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--color-mocha)' }}>
                Телефон *
              </label>
              <div className="relative">
                <Phone size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+7 (___) ___-__-__"
                  className="input-focus w-full pl-10 pr-4 py-2.5 rounded-lg border border-gray-200 outline-none"
                  style={{ fontSize: '15px' }}
                />
              </div>
            </div>

            {/* Guests */}
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--color-mocha)' }}>
                Количество гостей
              </label>
              <div className="relative">
                <Users size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <select
                  value={guests}
                  onChange={(e) => setGuests(Number(e.target.value))}
                  className="input-focus w-full pl-10 pr-4 py-2.5 rounded-lg border border-gray-200 outline-none appearance-none"
                  style={{ fontSize: '15px' }}
                >
                  {[1,2,3,4,5,6,7,8,9,10].map(n => (
                    <option key={n} value={n}>{n} {n === 1 ? 'гость' : n < 5 ? 'гостя' : 'гостей'}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Date & Time */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--color-mocha)' }}>
                  Дата *
                </label>
                <div className="relative">
                  <Calendar size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                  <input
                    type="date"
                    min={today}
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="input-focus w-full pl-10 pr-2 py-2.5 rounded-lg border border-gray-200 outline-none"
                    style={{ fontSize: '15px' }}
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--color-mocha)' }}>
                  Время *
                </label>
                <div className="relative">
                  <Clock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
                  <select
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    className="input-focus w-full pl-10 pr-2 py-2.5 rounded-lg border border-gray-200 outline-none appearance-none"
                    style={{ fontSize: '15px' }}
                  >
                    <option value="">Выбрать</option>
                    {TIME_SLOTS.map(t => (
                      <option key={t} value={t}>{t}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Comment */}
            <div>
              <label className="block text-sm font-medium mb-1.5" style={{ color: 'var(--color-mocha)' }}>
                Комментарий
              </label>
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Пожелания к бронированию..."
                rows={2}
                className="input-focus w-full px-4 py-2.5 rounded-lg border border-gray-200 outline-none resize-none"
                style={{ fontSize: '15px' }}
              />
            </div>

            {/* Error */}
            {status === 'error' && (
              <p className="text-sm text-red-500">{errorMsg}</p>
            )}

            {/* Submit */}
            <button
              type="submit"
              disabled={status === 'loading'}
              className="btn-primary-hover w-full py-3.5 rounded-full text-white font-semibold flex items-center justify-center gap-2 disabled:opacity-60"
              style={{ background: 'linear-gradient(135deg, #c87f2a, #e0a83b)' }}
            >
              {status === 'loading' ? (
                <>
                  <Loader2 size={20} className="animate-spin" />
                  Отправка...
                </>
              ) : (
                'Забронировать'
              )}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
