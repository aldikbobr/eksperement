import { useState, useRef } from 'react';
import {
  ArrowLeft, UtensilsCrossed, Coffee, Briefcase, Clock,
  Flame, Soup, Salad, Croissant, Wheat, Beef, IceCream, GlassWater, CupSoda,
  LayoutGrid, ChevronLeft, ChevronRight, Minus, Plus,
  ShoppingBag, CheckCircle2, X,
} from 'lucide-react';

const ORDER_PHONE_NUMBER = '77752728282';

type Category = 'breakfast' | 'business' | 'blini' | 'hot' | 'soups' | 'salads' | 'snacks' | 'porridge' | 'garnish' | 'desserts' | 'shakes' | 'lemonades' | 'hotdrinks';

interface Dish {
  name: string;
  desc: string;
  price: string;
  tags?: string[];
  items?: string[];
  isSectionHeader?: boolean;
}

const MENU: Record<Category, { title: string; icon: typeof UtensilsCrossed; image: string; dishes: Dish[] }> = {
  breakfast: {
    title: 'Завтраки',
    icon: Coffee,
    image: 'https://images.pexels.com/photos/4966595/pexels-photo-4966595.jpeg?auto=compress&cs=tinysrgb&w=1920',
    dishes: [
      {
        name: 'Завтрак 1',
        desc: 'Сытный завтрак на весь день',
        price: '3200 ₸',
        items: ['Глазунья (2 яйца)', 'Драники (3 шт)', 'Колбаски (2 шт)', 'Овощной салат', 'Фасоль в красном соусе', 'Чай'],
      },
      {
        name: 'Завтрак 2',
        desc: 'Куриные оладьи и блинчики с моцареллой',
        price: '3200 ₸',
        items: ['Глазунья (2 яйца)', 'Куриные оладьи (2 шт)', 'Блинчики с моцареллой (2 шт)', 'Овощной салат', 'Фасоль в красном соусе', 'Чай'],
      },
      {
        name: 'Завтрак 3',
        desc: 'Овсяная каша, сырники и блинчики',
        price: '3000 ₸',
        items: ['Каша овсяная с орехами и сухофруктами', 'Сырники кокосовые со сгущенкой (3 шт)', 'Блинчики с яблоком и корицей (2 шт)', 'Чай'],
      },
      {
        name: 'Завтрак 4',
        desc: 'Сёмга слабой соли с греческим салатом',
        price: '3500 ₸',
        items: ['Вареные яйца (2 шт)', 'Семга слабой соли', 'Греческий салат', 'Блинчики (3 шт)', 'Чай'],
      },
      {
        name: 'Сет из блинчиков',
        desc: 'Четыре вида блинчиков с соусами',
        price: '3200 ₸',
        items: ['Блинчики с ветчиной и сыром (2 шт)', 'Блинчики по-мексикански (2 шт)', 'Блинчики с зелёным луком и яйцом (2 шт)', 'Блинчики (5 шт)', 'Сметана, грибной соус, соус сладкий чили'],
      },
    ],
  },
  business: {
    title: 'Бизнес-ланчи',
    icon: Briefcase,
    image: 'https://images.pexels.com/photos/163018/food-business-lunch-restaurant-lunch-163018.jpeg?auto=compress&cs=tinysrgb&w=1920',
    dishes: [
      {
        name: 'Обед 1',
        desc: 'Окрошка, куриные оладьи с пюре, блинчики',
        price: '2900 ₸',
        items: ['Окрошка с куриной ветчиной', 'Оладьи куриные с пюре', 'Блинчики со сметаной', 'Чай'],
      },
      {
        name: 'Обед 2',
        desc: 'Суп лапша, битые огурцы, жареная рыба',
        price: '2900 ₸',
        items: ['Суп лапша', 'Битые огурцы', 'Рыба жареная с картофельным пюре', 'Чай'],
      },
      {
        name: 'Обед 3',
        desc: 'Греческий салат, лагман, блинчики со сгущёнкой',
        price: '2900 ₸',
        items: ['Салат греческий', 'Лагман', 'Блинчики со сгущенкой', 'Чай'],
      },
      {
        name: 'Обед 4',
        desc: 'Солянка, утиная грудка с чечевичным пюре',
        price: '2900 ₸',
        items: ['Солянка', 'Утиная грудка с чечевичным пюре', 'Блинчики с джемом', 'Чай'],
      },
    ],
  },
  blini: {
    title: 'Блины',
    icon: UtensilsCrossed,
    image: 'https://images.pexels.com/photos/574111/pexels-photo-574111.jpeg?auto=compress&cs=tinysrgb&w=1920',
    dishes: [
      { name: 'Сытные блинчики', desc: '', price: '', isSectionHeader: true },
      { name: 'Блинчатые ракушки с красной рыбой', desc: 'Хрустящие блинные конверты с сёмгой и сливочным сыром', price: '1700 ₸' },
      { name: 'Блинные роллы с красной рыбой', desc: 'Тонкие блинчики, свёрнутые роллами с красной рыбой и зеленью', price: '1700 ₸' },
      { name: 'Блинчики с мясным фаршем и рисом', desc: 'Сочная начинка из говяжьего фарша с рисом и специями', price: '1000 ₸' },
      { name: 'Блинчики с зелёным луком и яйцом', desc: 'Классическая начинка: варёное яйцо с зелёным луком', price: '1000 ₸' },
      { name: 'Блинчики с ветчиной и сыром', desc: 'Ветчина и расплавленный сыр в золотистом блинчике', price: '1100 ₸' },
      { name: 'Блинчики с куриным жульеном', desc: 'Куриное филе с грибами в сливочном соусе', price: '1200 ₸' },
      { name: 'Блинное хачапури', desc: 'Блинчик в форме лодочки с сулугуни и маслом', price: '1200 ₸' },
      { name: 'Блинчики с копчёной уткой, томатами и моцареллой', desc: 'Деликатесная утка с томатами черри и моцареллой', price: '1300 ₸' },
      { name: 'Блинная пицца', desc: 'Блинчик-основа с томатным соусом, сыром и начинкой', price: '1300 ₸' },
      { name: 'Блинчики по-мексикански', desc: 'Острая начинка из фасоли, кукурузы и перца', price: '1300 ₸', tags: ['New'] },
      { name: 'Блинчики', desc: 'Без начинки — к любому соусу или блюду', price: '90 ₸/шт' },

      { name: 'Сладкие блинчики', desc: '', price: '', isSectionHeader: true },
      { name: 'Блинчики с творогом', desc: 'Нежный творог с изюмом и ванилью', price: '1000 ₸' },
      { name: 'Блинный яблочный штрудель', desc: 'Карамелизированные яблоки с корицей в хрустящем блинчике', price: '1000 ₸' },
      { name: 'Блинчики с горячей ягодой', desc: 'Тёплая ягодная начинка с шариком мороженого', price: '1200 ₸' },
      { name: 'Блинчики с мороженым и бананом', desc: 'Банан и ванильное мороженое в блинчике-конверте', price: '1300 ₸' },
      { name: 'Блинчики Синнабон', desc: 'Корица и сливочная глазурь в нежном блинчике', price: '1300 ₸' },
      { name: 'Блинчики Орео', desc: 'Крошка печенья Oreo со сгущённым молоком', price: '1300 ₸', tags: ['New'] },
      { name: 'Блинчики мамины', desc: 'Домашний рецепт: сгущёнка и сливочное масло', price: '1300 ₸' },
      { name: 'Блинчики со сметаной/сгущ. молоком/мёдом/джемом', desc: 'Классические блинчики с любимой заправкой на выбор', price: '550 ₸' },
    ],
  },
  hot: {
    title: 'Горячие блюда',
    icon: Flame,
    image: 'https://images.pexels.com/photos/4005238/pexels-photo-4005238.jpeg?auto=compress&cs=tinysrgb&w=1920',
    dishes: [
      { name: 'Чахохбили', desc: 'Тушёная курица в томатном соусе с луком, чесноком и свежей зеленью', price: '1500 ₸' },
      { name: 'Шницель куриный', desc: 'Отбитое куриное филе в хрустящей панировке, подаётся с гарниром', price: '1800 ₸' },
      { name: 'Куриное филе с томатами и моцареллой', desc: 'Запечённое филе под сырной шапкой с томатами черри', price: '1800 ₸' },
      { name: 'Оладьи из куриной грудки', desc: 'Нежные куриные оладьи со сметанным соусом', price: '1400 ₸' },
      { name: 'Ростбиф по-монастырски', desc: 'Сочный ростбиф с грибами и луком в насыщенном соусе', price: '3000 ₸' },
      { name: 'Мини-чебуреки с соусом сальса', desc: 'Хрустящие чебуреки с мясной начинкой и пикантным соусом', price: '1200 ₸' },
      { name: 'Жареный рис с курицей и овощами', desc: 'Рис вок с курицей, овощами и соевым соусом', price: '1700 ₸', tags: ['New'] },
      { name: 'Котлета из говядины', desc: 'Домашняя котлета из рубленой говядины со специями', price: '1000 ₸' },
      { name: 'Пельмени', desc: 'Классические пельмени из тонкого теста и мясной начинки', price: '1200 ₸' },
      { name: 'Пельмени жареные с сыром', desc: 'Обжаренные пельмени с румяной сырной корочкой', price: '1400 ₸' },
      { name: 'Пельмени в горшочках', desc: 'Запечённые пельмени в керамическом горшочке со сметаной и зеленью', price: '1400 ₸' },
      { name: 'Вареники с творогом', desc: 'Вареники с нежным творогом, подаются со сметаной', price: '1200 ₸' },
      { name: 'Вареники с картофелем', desc: 'Вареники с картофельным пюре и обжаренным луком', price: '1100 ₸' },
      { name: 'Жареные вареники с картофелем и сыром сулугуни', desc: 'Хрустящие вареники с картофелем и тягучим сулугуни', price: '1300 ₸' },
    ],
  },
  soups: {
    title: 'Супы',
    icon: Soup,
    image: 'https://images.pexels.com/photos/15403396/pexels-photo-15403396.jpeg?auto=compress&cs=tinysrgb&w=1920',
    dishes: [
      { name: 'Суп лапша по-домашнему', desc: 'Домашняя лапша с курицей и овощами', price: '1000 ₸' },
      { name: 'Окрошка с копчёной курицей', desc: 'Освежающая окрошка на квасе с копчёной курицей', price: '1300 ₸', tags: ['New'] },
      { name: 'Чечевичный суп', desc: 'Сытный суп из чечевицы с овощами и специями', price: '1100 ₸' },
      { name: 'Тыквенный крем-суп', desc: 'Нежный крем-суп из тыквы со сливками', price: '1200 ₸' },
      { name: 'Борщ со сметаной', desc: 'Классический борщ с говядиной и сметаной', price: '1300 ₸' },
      { name: 'Бульон с пельменями', desc: 'Прозрачный бульон с домашними пельменями', price: '1500 ₸' },
      { name: 'Мясо по-казахски', desc: 'Традиционное казахское блюдо с мясом и бульоном', price: '1300 ₸' },
      { name: 'Солянка', desc: 'Острая солянка с мясными деликатесами и оливками', price: '1500 ₸' },
      { name: 'Уха по-фински', desc: 'Сливочная уха с лососем и картофелем', price: '1700 ₸' },
      { name: 'Лагман', desc: 'Восточный суп с лапшой, мясом и овощами', price: '1500 ₸' },
    ],
  },
  salads: {
    title: 'Салаты',
    icon: Salad,
    image: 'https://images.pexels.com/photos/842545/pexels-photo-842545.jpeg?auto=compress&cs=tinysrgb&w=1920',
    dishes: [
      { name: 'Салат Битые огурцы', desc: 'Свежие огурцы с чесноком и пикантной заправкой', price: '900 ₸', tags: ['New'] },
      { name: 'Салат Ачичук', desc: 'Тонко нарезанные томаты, лук и перец с зеленью', price: '900 ₸', tags: ['New'] },
      { name: 'Салат Весенний', desc: 'Лёгкий салат со свежей зеленью и овощами', price: '900 ₸', tags: ['New'] },
      { name: 'Салат Крабовый', desc: 'Крабовые палочки с кукурузой, яйцом и майонезом', price: '1200 ₸' },
      { name: 'Салат Оливье с ветчиной', desc: 'Классический оливье с ветчиной и солёными огурцами', price: '1200 ₸' },
      { name: 'Сельдь по-русски', desc: 'Сельдь с луком и картофелем по традиционному рецепту', price: '1300 ₸' },
      { name: 'Нарезка греческая', desc: 'Томаты, огурцы, перец, сыр фета и маслины', price: '1300 ₸' },
      { name: 'Салат Рог изобилия', desc: 'Сытный салат с курицей, овощами и пикантным соусом', price: '1300 ₸' },
      { name: 'Салат Тбилиси', desc: 'Острый салат с говядиной, фасолью и специями', price: '1300 ₸' },
      { name: 'Салат Дублёр', desc: 'Слоёный салат с курицей, грибами и сыром', price: '1300 ₸' },
    ],
  },
  snacks: {
    title: 'Горячие закуски',
    icon: Croissant,
    image: 'https://images.pexels.com/photos/5639416/pexels-photo-5639416.jpeg?auto=compress&cs=tinysrgb&w=1920',
    dishes: [
      { name: 'Жульен куриный с грибами', desc: 'Куриное филе с шампиньонами в сливочном соусе под сырной корочкой', price: '1200 ₸' },
      { name: 'Яичница с ветчиной', desc: 'Два яйца-глазунья с обжаренной ветчиной и зеленью', price: '1200 ₸' },
      { name: 'Яичница с помидором и сыром', desc: 'Яичница с томатами и расплавленным сыром', price: '1200 ₸' },
      { name: 'Яичница глазунья', desc: 'Классическая глазунья из двух яиц с золотистыми краями', price: '750 ₸' },
      { name: 'Драники со сметаной', desc: 'Хрустящие картофельные оладьи с домашней сметаной', price: '1350 ₸' },
    ],
  },
  porridge: {
    title: 'Каши и сырники',
    icon: Wheat,
    image: 'https://images.pexels.com/photos/10877314/pexels-photo-10877314.jpeg?auto=compress&cs=tinysrgb&w=1920',
    dishes: [
      { name: 'Каша овсяная', desc: 'Классическая овсяная каша на молоке', price: '750 ₸' },
      { name: 'Каша овсяная с карамелизированным арахисом и шоколадом', desc: 'Овсянка с хрустящим арахисом в карамели и шоколадом', price: '1100 ₸', tags: ['New'] },
      { name: 'Каша овсяная с клубникой и бананом', desc: 'Овсянка со свежей клубникой и бананом', price: '1200 ₸' },
      { name: 'Каша манная', desc: 'Нежная манная каша на молоке', price: '750 ₸' },
      { name: 'Каша манная с варёной сгущёнкой и орехами', desc: 'Манная каша с варёной сгущёнкой и грецкими орехами', price: '1100 ₸' },
      { name: 'Сырники со сметаной/джемом/сгущёнкой', desc: 'Золотистые сырники с заправкой на выбор', price: '1000 ₸' },
    ],
  },
  garnish: {
    title: 'Гарниры',
    icon: Beef,
    image: 'https://images.pexels.com/photos/128641/pexels-photo-128641.jpeg?auto=compress&cs=tinysrgb&w=1920',
    dishes: [
      { name: 'Пюре картофельное', desc: 'Нежное картофельное пюре на молоке и масле', price: '500 ₸' },
      { name: 'Пюре гороховое', desc: 'Густое гороховое пюре с обжаренным луком', price: '500 ₸' },
      { name: 'Рис', desc: 'Рассыпчатый рис, сваренный на пару', price: '400 ₸' },
      { name: 'Овощи жареные', desc: 'Ассорти из сезонных овощей, обжаренных на сковороде', price: '700 ₸' },
      { name: 'Каша гречневая', desc: 'Рассыпчатая гречневая каша', price: '400 ₸' },
    ],
  },
  desserts: {
    title: 'Сладкие блюда',
    icon: IceCream,
    image: 'https://images.pexels.com/photos/34964934/pexels-photo-34964934.jpeg?auto=compress&cs=tinysrgb&w=1920',
    dishes: [
      { name: 'Мороженое с ягодами', desc: 'Ванильное мороженое со свежими ягодами', price: '1000 ₸' },
      { name: 'Мороженое с бананом и шоколадом', desc: 'Мороженое с бананом и тёплым шоколадом', price: '1000 ₸' },
    ],
  },
  shakes: {
    title: 'Молочные коктейли',
    icon: GlassWater,
    image: 'https://images.pexels.com/photos/28525197/pexels-photo-28525197.jpeg?auto=compress&cs=tinysrgb&w=1920',
    dishes: [
      { name: 'Коктейль молочный', desc: 'Классический молочный коктейль (300/500 мл)', price: '700/950 ₸' },
      { name: 'Коктейль шоколадный', desc: 'Шоколадный молочный коктейль (300/500 мл)', price: '700/950 ₸' },
      { name: 'Коктейль клубничный', desc: 'Клубничный молочный коктейль (300/500 мл)', price: '700/950 ₸' },
    ],
  },
  lemonades: {
    title: 'Лимонады',
    icon: CupSoda,
    image: 'https://images.pexels.com/photos/9259573/pexels-photo-9259573.jpeg?auto=compress&cs=tinysrgb&w=1920',
    dishes: [
      { name: 'Тархун', desc: 'Освежающий лимонад с эстрагоном (стакан/кувшин)', price: '950/3000 ₸' },
      { name: 'Апероль', desc: 'Цитрусовый лимонад с апельсином (стакан/кувшин)', price: '950/3000 ₸' },
      { name: 'Мохито клубничный', desc: 'Мятный лимонад с клубникой (стакан/кувшин)', price: '950/3000 ₸' },
      { name: 'Мохито', desc: 'Классический мятный лимонад с лаймом (стакан/кувшин)', price: '950/3000 ₸' },
      { name: 'Мохито алкогольный', desc: 'Мятный коктейль с ромом и лаймом', price: '1400 ₸' },
    ],
  },
  hotdrinks: {
    title: 'Горячие напитки',
    icon: Coffee,
    image: 'https://images.pexels.com/photos/2011264/pexels-photo-2011264.jpeg?auto=compress&cs=tinysrgb&w=1920',
    dishes: [
      { name: 'Чай чёрный/зелёный пакетированный', desc: 'На выбор: чёрный или зелёный чай в пакетиках', price: '300 ₸' },
      { name: 'Чай с лимоном/молоком', desc: 'Чай с долькой лимона или молоком', price: '350 ₸' },
      { name: 'Чай чёрный/зелёный (чайник)', desc: 'Большой заварочный чайник на компанию', price: '900 ₸' },
      { name: 'Чай «Имбирный апельсин»', desc: 'Ароматный чай с имбирём и апельсином', price: '1300 ₸' },
      { name: 'Чай «Яблоко и шиповник»', desc: 'Фруктовый чай с яблоком и шиповником', price: '1300 ₸' },
      { name: 'Чай «Медовая липа»', desc: 'Чай с цветами липы и мёдом', price: '1300 ₸' },
      { name: 'Чай «Клубника-ананас»', desc: 'Сладкий чай с клубникой и ананасом', price: '1300 ₸' },
      { name: 'Чай по-ташкентски', desc: 'Традиционный ташкентский чай со специями', price: '1500 ₸' },
      { name: 'Кофе растворимый', desc: 'Чашка растворимого кофе', price: '600 ₸' },
      { name: 'Кофе растворимый с молоком', desc: 'Растворимый кофе с молоком', price: '650 ₸' },
      { name: 'Кофе по-турецки', desc: 'Крепкий кофе, сваренный в турке', price: '750 ₸' },
      { name: 'Американо', desc: 'Чёрный фильтр-кофе без молока', price: '700 ₸' },
      { name: 'Капучино', desc: 'Эспрессо с нежной молочной пенкой', price: '900 ₸' },
    ],
  },
};

const CATEGORY_ORDER: Category[] = ['breakfast', 'business', 'blini', 'hot', 'soups', 'salads', 'snacks', 'porridge', 'garnish', 'desserts', 'shakes', 'lemonades', 'hotdrinks'];

const DISH_PRICE_MAP: Record<string, number> = {};
Object.values(MENU).forEach(c => {
  c.dishes.forEach(d => {
    if (!d.isSectionHeader && d.price) {
      const m = d.price.match(/(\d+)/);
      if (m) DISH_PRICE_MAP[d.name] = parseInt(m[1], 10);
    }
  });
});

interface MenuPageProps {
  onBack: () => void;
}

export default function MenuPage({ onBack }: MenuPageProps) {
  const [active, setActive] = useState<Category>('breakfast');
  const [showAll, setShowAll] = useState(false);
  const [quantities, setQuantities] = useState<Record<string, number>>({});
  const [orderPlaced, setOrderPlaced] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const cat = MENU[active];
  const visibleDishes = showAll ? cat.dishes : cat.dishes.slice(0, 6);
  const totalDishes = cat.dishes.filter(d => !d.isSectionHeader).length;

  const getQty = (name: string) => quantities[name] ?? 0;
  const inc = (name: string) => setQuantities(q => ({ ...q, [name]: (q[name] ?? 0) + 1 }));
  const dec = (name: string) => setQuantities(q => ({ ...q, [name]: Math.max(0, (q[name] ?? 0) - 1) }));

  const totalCount = Object.values(quantities).reduce((s, q) => s + q, 0);
  const totalSum = Object.entries(quantities).reduce((s, [name, q]) => s + (DISH_PRICE_MAP[name] ?? 0) * q, 0);

  const handleOrder = () => {
    if (totalCount === 0) return;
    const lines: string[] = ['Новый заказ «Блинный домик»', ''];
    Object.entries(quantities).forEach(([name, qty]) => {
      if (qty > 0) {
        const price = DISH_PRICE_MAP[name] ?? 0;
        lines.push(`• ${name} ×${qty} — ${price * qty} ₸`);
      }
    });
    lines.push('', `Итого: ${totalSum} ₸`);
    const text = encodeURIComponent(lines.join('\n'));
    window.open(`https://wa.me/${ORDER_PHONE_NUMBER}?text=${text}`, '_blank', 'noopener,noreferrer');
    setQuantities({});
    setOrderPlaced(true);
  };

  const handleCategoryChange = (key: Category) => {
    setActive(key);
    setShowAll(false);
  };

  const scrollTabs = (dir: 'left' | 'right') => {
    const el = scrollRef.current;
    if (!el) return;
    const amount = el.clientWidth * 0.7;
    el.scrollBy({ left: dir === 'left' ? -amount : amount, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen" style={{ background: 'var(--color-cream)' }}>
      {/* Header banner */}
      <div className="relative h-72 md:h-80 overflow-hidden">
        <img src={cat.image} alt={cat.title} className="w-full h-full object-cover transition-all duration-500" />
        <div className="absolute inset-0" style={{ background: 'linear-gradient(180deg, rgba(43,33,24,0.4) 0%, rgba(43,33,24,0.75) 100%)' }} />
        <div className="absolute inset-0 flex flex-col">
          <div className="max-w-7xl mx-auto w-full px-5 pt-6 flex items-center justify-between">
            <button
              onClick={onBack}
              className="btn-hover flex items-center gap-2 px-4 py-2 rounded-full text-white text-sm font-medium"
              style={{ background: 'rgba(255,255,255,0.15)', backdropFilter: 'blur(8px)' }}
            >
              <ArrowLeft size={16} />
              Назад
            </button>
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: 'var(--color-golden)' }}>
                <UtensilsCrossed size={18} className="text-white" />
              </div>
              <span className="text-lg font-bold text-white">Блинный домик</span>
            </div>
          </div>
          <div className="flex-1 flex flex-col items-center justify-center text-center px-5">
            <span className="text-sm font-semibold uppercase tracking-widest text-white/70 mb-2">Полное меню</span>
            <h1 className="text-4xl md:text-5xl font-bold text-white" style={{ textShadow: '0 4px 20px rgba(0,0,0,0.4)' }}>
              {cat.title}
            </h1>
          </div>
        </div>
      </div>

      {/* Mobile category tabs — horizontal scroll with arrow buttons */}
      <div className="lg:hidden sticky top-0 z-30 border-b border-gray-200/60" style={{ background: 'rgba(250,246,240,0.95)', backdropFilter: 'blur(10px)' }}>
        <div className="flex items-center">
          <button
            onClick={() => scrollTabs('left')}
            className="shrink-0 w-10 h-12 flex items-center justify-center transition-opacity duration-200"
            style={{ color: 'var(--color-mocha)' }}
            aria-label="Прокрутить влево"
          >
            <ChevronLeft size={22} />
          </button>
          <div
            ref={scrollRef}
            className="flex-1 flex items-center gap-2 overflow-x-auto no-scrollbar scroll-smooth"
          >
            {CATEGORY_ORDER.map((key) => {
              const c = MENU[key];
              const isActive = key === active;
              return (
                <button
                  key={key}
                  onClick={() => handleCategoryChange(key)}
                  className={`btn-hover flex items-center gap-2 px-4 py-2.5 rounded-full text-sm font-semibold whitespace-nowrap transition-all duration-300 ${
                    isActive ? 'text-white' : ''
                  }`}
                  style={isActive ? { background: 'linear-gradient(135deg, #c87f2a, #e0a83b)' } : { background: '#fff', color: 'var(--color-mocha)', border: '1px solid #e5e0d6' }}
                >
                  <c.icon size={16} style={isActive ? { color: '#fff' } : { color: 'var(--color-amber)' }} />
                  {c.title}
                </button>
              );
            })}
          </div>
          <button
            onClick={() => scrollTabs('right')}
            className="shrink-0 w-10 h-12 flex items-center justify-center transition-opacity duration-200"
            style={{ color: 'var(--color-mocha)' }}
            aria-label="Прокрутить вправо"
          >
            <ChevronRight size={22} />
          </button>
        </div>
      </div>

      {/* Main layout: sidebar + content */}
      <div className="max-w-7xl mx-auto px-5 py-8 flex gap-8">
        {/* Desktop sidebar */}
        <aside className="hidden lg:block w-64 shrink-0">
          <div className="sticky top-6">
            <div className="flex items-center gap-2 mb-4 px-2">
              <LayoutGrid size={18} style={{ color: 'var(--color-amber)' }} />
              <h2 className="text-sm font-bold uppercase tracking-wider" style={{ color: 'var(--color-mocha)' }}>Категории</h2>
            </div>
            <div className="space-y-1">
              {CATEGORY_ORDER.map((key) => {
                const c = MENU[key];
                const isActive = key === active;
                const count = c.dishes.filter(d => !d.isSectionHeader).length;
                return (
                  <button
                    key={key}
                    onClick={() => handleCategoryChange(key)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 ${
                      isActive ? 'text-white shadow-md' : ''
                    }`}
                    style={isActive
                      ? { background: 'linear-gradient(135deg, #c87f2a, #e0a83b)' }
                      : { color: 'var(--color-mocha)', background: 'transparent' }
                    }
                  >
                    <c.icon size={18} style={isActive ? { color: '#fff' } : { color: 'var(--color-amber)' }} />
                    <span className="flex-1 text-left">{c.title}</span>
                    <span
                      className="text-xs px-2 py-0.5 rounded-full"
                      style={isActive
                        ? { background: 'rgba(255,255,255,0.25)', color: '#fff' }
                        : { background: '#f0ebe0', color: 'var(--color-mocha)' }
                      }
                    >
                      {count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </aside>

        {/* Dish list */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3 mb-6">
            <cat.icon size={28} style={{ color: 'var(--color-amber)' }} />
            <div>
              <h2 className="text-2xl font-bold" style={{ color: 'var(--color-dark)' }}>{cat.title}</h2>
              <p className="text-sm flex items-center gap-1.5" style={{ color: 'var(--color-mocha)' }}>
                <Clock size={14} />
                {totalDishes} блюд в категории
              </p>
            </div>
          </div>

          {cat.dishes.length > 0 ? (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-5">
                {visibleDishes.map((dish, i) => {
                  const isHeader = dish.isSectionHeader;
                  if (isHeader) {
                    return (
                      <div key={i} className="col-span-full mt-8 first:mt-0">
                        <div className="flex items-center gap-4">
                          <h3 className="text-2xl font-bold tracking-wide whitespace-nowrap" style={{ color: 'var(--color-amber)' }}>
                            {dish.name}
                          </h3>
                          <div className="flex-1 h-px" style={{ background: 'linear-gradient(90deg, var(--color-amber), transparent)' }} />
                        </div>
                      </div>
                    );
                  }
                  return (
                    <div
                      key={i}
                      className="card-hover bg-white rounded-2xl p-5 md:p-6 border border-gray-100"
                      style={{ animation: `fadeUp 0.5s ease ${i * 60}ms both` }}
                    >
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold mb-1" style={{ color: 'var(--color-dark)' }}>
                            {dish.name}
                          </h3>
                          {dish.desc && (
                            <p className="text-sm mb-3" style={{ color: 'var(--color-mocha)' }}>
                              {dish.desc}
                            </p>
                          )}
                          {dish.items && (
                            <ul className="space-y-1.5 mb-3">
                              {dish.items.map((item, k) => (
                                <li key={k} className="flex items-center gap-2 text-sm" style={{ color: 'var(--color-mocha)' }}>
                                  <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: 'var(--color-amber)' }} />
                                  {item}
                                </li>
                              ))}
                            </ul>
                          )}
                          {dish.tags && (
                            <div className="flex flex-wrap gap-1.5">
                              {dish.tags.map((tag, j) => (
                                <span
                                  key={j}
                                  className="text-xs px-2.5 py-1 rounded-full"
                                  style={{ background: 'var(--color-warm)', color: 'var(--color-mocha)' }}
                                >
                                  {tag}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                        <div className="flex flex-col items-end gap-3 shrink-0">
                          <span className="text-lg font-bold" style={{ color: 'var(--color-amber)' }}>
                            {dish.price}
                          </span>
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => dec(dish.name)}
                              disabled={getQty(dish.name) === 0}
                              className="w-9 h-9 rounded-full flex items-center justify-center transition-all duration-200 disabled:opacity-30"
                              style={{ background: 'var(--color-warm)', color: 'var(--color-mocha)' }}
                              aria-label="Уменьшить"
                            >
                              <Minus size={18} />
                            </button>
                            <span className="w-8 text-center text-base font-bold tabular-nums" style={{ color: 'var(--color-dark)' }}>
                              {getQty(dish.name)}
                            </span>
                            <button
                              onClick={() => inc(dish.name)}
                              className="w-9 h-9 rounded-full flex items-center justify-center transition-all duration-200 text-white"
                              style={{ background: 'linear-gradient(135deg, #c87f2a, #e0a83b)' }}
                              aria-label="Увеличить"
                            >
                              <Plus size={18} />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {cat.dishes.length > 6 && !showAll && (
                <div className="text-center mt-8">
                  <button
                    onClick={() => setShowAll(true)}
                    className="btn-hover inline-flex items-center gap-2 px-6 py-3 rounded-full font-semibold transition-all duration-300"
                    style={{ background: '#fff', color: 'var(--color-mocha)', border: '2px solid var(--color-amber)' }}
                  >
                    Показать все {totalDishes} блюд
                  </button>
                </div>
              )}
            </>
          ) : (
            <div className="text-center py-16">
              <cat.icon size={48} className="mx-auto mb-4 opacity-30" style={{ color: 'var(--color-mocha)' }} />
              <p className="text-lg font-medium" style={{ color: 'var(--color-mocha)' }}>
                Меню скоро будет добавлено
              </p>
              <p className="text-sm mt-1" style={{ color: 'var(--color-mocha)', opacity: 0.6 }}>
                Мы готовим эту категорию для вас
              </p>
            </div>
          )}

          <div className="text-center mt-12">
            <button
              onClick={onBack}
              className="btn-hover px-7 py-3.5 rounded-full text-white font-semibold"
              style={{ background: 'linear-gradient(135deg, #c87f2a, #e0a83b)' }}
            >
              <span className="flex items-center gap-2 justify-center">
                <ArrowLeft size={18} />
                Вернуться на главную
              </span>
            </button>
          </div>
        </div>
      </div>

      <footer className="py-10 px-5 text-center" style={{ background: 'var(--color-dark)' }}>
        <p className="text-sm text-white/50">
          Кафе «Блинный домик» · ул. Абая 25, Петропавловск · 8 (7152) 46 70 26
        </p>
        <p className="text-xs text-white/30 mt-2">© 2026 Кафе «Блинный домик»</p>
      </footer>

      {/* Sticky order bar */}
      <div className="fixed bottom-0 left-0 right-0 z-40 px-4 pb-4 pt-2" style={{ background: 'linear-gradient(180deg, transparent, rgba(250,246,240,0.95) 30%)' }}>
        <div className="max-w-7xl mx-auto flex items-center gap-4">
          <div className="flex-1 hidden sm:block">
            {totalCount > 0 ? (
              <p className="text-sm font-medium" style={{ color: 'var(--color-mocha)' }}>
                {totalCount} {totalCount === 1 ? 'блюдо' : totalCount < 5 ? 'блюда' : 'блюд'} в заказе
              </p>
            ) : (
              <p className="text-sm" style={{ color: 'var(--color-mocha)', opacity: 0.5 }}>
                Добавьте блюда в заказ
              </p>
            )}
          </div>
          <button
            onClick={handleOrder}
            disabled={totalCount === 0}
            className="flex-1 sm:flex-none flex items-center justify-center gap-3 px-6 py-4 rounded-2xl font-bold text-white text-lg transition-all duration-200 disabled:cursor-not-allowed"
            style={totalCount === 0
              ? { background: '#c0bdb8' }
              : { background: '#E63946', boxShadow: '0 6px 20px rgba(230,57,70,0.4)' }
            }
          >
            <ShoppingBag size={22} />
            <span>Заказать{totalCount > 0 ? ` (${totalCount})` : ''}</span>
            {totalCount > 0 && (
              <span className="hidden sm:inline text-base font-semibold opacity-90">
                · {totalSum} ₸
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Order confirmation modal */}
      {orderPlaced && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 overlay-in"
          style={{ background: 'rgba(43,33,24,0.6)', backdropFilter: 'blur(4px)' }}
          onClick={() => setOrderPlaced(false)}
        >
          <div
            className="modal-in w-full max-w-sm rounded-2xl bg-white shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setOrderPlaced(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
              aria-label="Закрыть"
            >
              <X size={22} />
            </button>
            <div className="px-6 py-10 text-center">
              <div className="mx-auto mb-4 w-16 h-16 rounded-full flex items-center justify-center" style={{ background: '#e8f5e9' }}>
                <CheckCircle2 size={36} style={{ color: '#4caf50' }} />
              </div>
              <h3 className="text-xl font-semibold mb-2" style={{ color: 'var(--color-dark)' }}>
                Заказ отправлен!
              </h3>
              <p className="text-sm mb-6" style={{ color: 'var(--color-mocha)' }}>
                Ваш заказ открыт в WhatsApp. Отправьте сообщение, чтобы мы его получили.
              </p>
              <button
                onClick={() => setOrderPlaced(false)}
                className="btn-primary-hover px-8 py-3 rounded-full text-white font-medium"
                style={{ background: 'var(--color-amber)' }}
              >
                Готово
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
